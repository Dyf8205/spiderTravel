// ==UserScript==
// @name         Hook _fbp Cookie
// @namespace    traveloka
// @version      1.0
// @description  拦截 traveloka.com 下 _fbp cookie 的设置
// @match        https://www.traveloka.com/*
// @match        https://*.traveloka.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const cookieDesc = Object.getOwnPropertyDescriptor(Document.prototype, 'cookie') ||
                       Object.getOwnPropertyDescriptor(HTMLDocument.prototype, 'cookie');

    if (!cookieDesc) {
        console.error('[Hook _fbp] 无法获取 cookie 属性描述符');
        return;
    }

    const originalSet = cookieDesc.set;
    const originalGet = cookieDesc.get;

    Object.defineProperty(document, 'cookie', {
        get() {
            return originalGet.call(this);
        },
        set(value) {
            if (value && value.includes('_fbp=')) {
                console.log('[Hook _fbp] 捕获到 _fbp 设置:', value);
                console.trace('[Hook _fbp] 调用栈');
                // 如果要阻止设置，直接 return 不调用 originalSet
                // return;
            }
            return originalSet.call(this, value);
        },
        configurable: true
    });

    console.log('[Hook _fbp] hook 已注入');
})();
