(function() {
    try {
        var handle = (n => {
            function o(n) {
                window.Criteo = window.Criteo || {},
                window.Criteo.oneTagConfig = n
            }
            return n.default = function(n) {
                o(n.oneTagConfig)
            }
            ,
            n.setConfig = o,
            n
        }
        )({});
        handle.default({
            "urlsAsLink": [],
            "oneTagConfig": {
                "partnerId": [-1],
                "visitEventEnabled": true,
                "dynamic": true,
                "gumDomain": "gum.criteo.com",
                "privateModeDetectionEnabled": true,
                "blockedSteps": [],
                "excludedReferrerParams": [],
                "addClientSideSupportForId5": false,
                "useStaticConsentForId5": false,
                "shouldFillPageId": false,
                "enableOffsiteProjection": true,
                "enabledCspViolationDetection": true,
                "allowedDomainsForCsp": ["criteo.com", "criteo.net", "crto.in", "localhost", "127.0.0.1", "hlserve.com", "ctolabperfstats.com"],
                "styleIframes": false,
                "smartPiiCollectionEnabled": false,
                "smartPiiCollectionBlocklist": ["card", "pass", "security", "social"]
            }
        });
        !function(O) {
            "use strict";
            function l(e, a, s, c) {
                return new (s = s || Promise)(function(n, t) {
                    function i(e) {
                        try {
                            r(c.next(e))
                        } catch (e) {
                            t(e)
                        }
                    }
                    function o(e) {
                        try {
                            r(c.throw(e))
                        } catch (e) {
                            t(e)
                        }
                    }
                    function r(e) {
                        var t;
                        e.done ? n(e.value) : ((t = e.value)instanceof s ? t : new s(function(e) {
                            e(t)
                        }
                        )).then(i, o)
                    }
                    r((c = c.apply(e, a || [])).next())
                }
                )
            }
            function R(i, o) {
                var r, a, s, c = {
                    label: 0,
                    sent: function() {
                        if (1 & s[0])
                            throw s[1];
                        return s[1]
                    },
                    trys: [],
                    ops: []
                }, e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
                return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                    return this
                }
                ),
                e;
                function t(n) {
                    return function(e) {
                        var t = [n, e];
                        if (r)
                            throw new TypeError("Generator is already executing.");
                        for (; c; )
                            try {
                                if (r = 1,
                                a && (s = 2 & t[0] ? a.return : t[0] ? a.throw || ((s = a.return) && s.call(a),
                                0) : a.next) && !(s = s.call(a, t[1])).done)
                                    return s;
                                switch (a = 0,
                                (t = s ? [2 & t[0], s.value] : t)[0]) {
                                case 0:
                                case 1:
                                    s = t;
                                    break;
                                case 4:
                                    return c.label++,
                                    {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    c.label++,
                                    a = t[1],
                                    t = [0];
                                    continue;
                                case 7:
                                    t = c.ops.pop(),
                                    c.trys.pop();
                                    continue;
                                default:
                                    if (!(s = 0 < (s = c.trys).length && s[s.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        c = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!s || t[1] > s[0] && t[1] < s[3]))
                                        c.label = t[1];
                                    else if (6 === t[0] && c.label < s[1])
                                        c.label = s[1],
                                        s = t;
                                    else {
                                        if (!(s && c.label < s[2])) {
                                            s[2] && c.ops.pop(),
                                            c.trys.pop();
                                            continue
                                        }
                                        c.label = s[2],
                                        c.ops.push(t)
                                    }
                                }
                                t = o.call(i, c)
                            } catch (e) {
                                t = [6, e],
                                a = 0
                            } finally {
                                r = s = 0
                            }
                        if (5 & t[0])
                            throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }
                }
            }
            function c() {
                for (var e = 0, t = 0, n = arguments.length; t < n; t++)
                    e += arguments[t].length;
                for (var i = Array(e), o = 0, t = 0; t < n; t++)
                    for (var r = arguments[t], a = 0, s = r.length; a < s; a++,
                    o++)
                        i[o] = r[a];
                return i
            }
            (y = o = o || {}).Script = "Script",
            y.Fetch = "Fetch",
            y.Frame = "Frame",
            (y = p = p || {}).OneTagStatic = "OneTagStatic",
            y.OneTagDynamic = "OneTagDynamic",
            r.getSingleton = function(e, t, n) {
                var i = n = void 0 === n ? window : n;
                return "object" != typeof i.cto_csm_CspLogger && (i.cto_csm_CspLogger = new r(e,t,n)),
                i.cto_csm_CspLogger
            }
            ,
            r.prototype.setFlushInterval = function(e) {
                var t = this;
                this.window.clearInterval(this.intervalHandle),
                this.intervalHandle = this.window.setInterval(function() {
                    return l(t, void 0, void 0, function() {
                        return R(this, function(e) {
                            switch (e.label) {
                            case 0:
                                return [4, this.flush()];
                            case 1:
                                return [2, e.sent()]
                            }
                        })
                    })
                }, e)
            }
            ,
            r.prototype.registerListener = function() {
                var t = this;
                this.isRegistered || (this.isRegistered = !0,
                this.window.addEventListener("securitypolicyviolation", function(e) {
                    "report" === e.disposition || t.isCspRequestBlockedByCsp(e.blockedURI) || (t.isHostnameListened(e.blockedURI) || t.isHostnameListened(e.sourceFile)) && t.events.push(e)
                }))
            }
            ,
            r.prototype.setPartnerIds = function(e) {
                this.partnerIds = void 0 === e || 0 === e.length ? void 0 : c(e)
            }
            ,
            r.prototype.setClientRequestId = function(e) {
                this.clientRequestId = e
            }
            ,
            r.prototype.flush = function() {
                return l(this, void 0, void 0, function() {
                    var t, n, i, o;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            for (t = [],
                            n = []; 0 < this.events.length; )
                                t.push(this.events.shift()),
                                i = this.createCspViolationRequest(t),
                                (o = "https://" + this.backendHostname + this.pathName + "?q=" + encodeURIComponent(JSON.stringify(i))).length > this.sentRequestLengthHardLimit ? t = [] : (o.length > this.sentRequestLengthSoftLimit || 0 === this.events.length) && (t = [],
                                n.push(this.sendRequest(i.acceptedFormat, o)));
                            return [4, Promise.all(n)];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            r.prototype.addAllowedDomains = function(e) {
                e = c(this.allowedHostnames, e);
                this.allowedHostnames = Array.from(new Set(e))
            }
            ,
            r.prototype.isCspRequestBlockedByCsp = function(e) {
                e = this.toUrl(e);
                return void 0 !== e && e.hostname === this.backendHostname && e.pathname === this.pathName
            }
            ,
            r.prototype.isHostnameListened = function(e) {
                var t, e = this.toUrl(e);
                return void 0 !== e && (t = e.hostname,
                this.allowedHostnames.some(function(e) {
                    return t === e || t.endsWith("." + e)
                }))
            }
            ,
            r.prototype.toUrl = function(e) {
                try {
                    return new URL(e)
                } catch (e) {}
            }
            ,
            r.prototype.createCspViolationRequest = function(e) {
                var t = this;
                return {
                    acceptedFormat: this.getAcceptedFormat(),
                    callChainOrigin: this.callChainOrigin,
                    partnerIds: this.partnerIds,
                    violations: e.map(function(e) {
                        return t.createCspViolation(e)
                    })
                }
            }
            ,
            r.prototype.createCspViolation = function(e) {
                var t = e.originalPolicy.split(" ")[0];
                return {
                    blockedUri: e.blockedURI,
                    clientRequestId: this.clientRequestId,
                    documentUri: e.documentURI,
                    effectiveDirective: e.effectiveDirective,
                    originalDirective: t,
                    sourceFile: e.sourceFile
                }
            }
            ,
            r.prototype.getAcceptedFormat = function() {
                switch (this.callChainOrigin) {
                case p.OneTagStatic:
                case p.OneTagDynamic:
                    return o.Script;
                default:
                    var e = this.callChainOrigin;
                    throw new Error("Unhandled case: " + e)
                }
            }
            ,
            r.prototype.sendRequest = function(n, i) {
                return l(this, void 0, void 0, function() {
                    var t;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            switch (n) {
                            case o.Script:
                                t = this.sendScriptRequest.bind(this);
                                break;
                            case o.Fetch:
                                t = this.sendFetchRequest.bind(this);
                                break;
                            case o.Frame:
                                t = this.sendFrameRequest.bind(this);
                                break;
                            default:
                                throw new Error("Unhandled case: " + n)
                            }
                            return [4, t(i)];
                        case 1:
                            return e.sent(),
                            [2]
                        }
                    })
                })
            }
            ,
            r.prototype.sendScriptRequest = function(i) {
                return l(this, void 0, void 0, function() {
                    var t, n = this;
                    return R(this, function(e) {
                        return (t = this.window.document.createElement("script")).type = "text/javascript",
                        t.async = !0,
                        t.title = "Criteo CSP Script",
                        t.src = i,
                        this.window.document.body.appendChild(t),
                        setTimeout(function() {
                            return n.window.document.body.removeChild(t)
                        }, this.elementRemovalDelayMs),
                        [2]
                    })
                })
            }
            ,
            r.prototype.sendFetchRequest = function(t) {
                return l(this, void 0, void 0, function() {
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return e.trys.push([0, 2, , 3]),
                            [4, fetch(t)];
                        case 1:
                        case 2:
                            return e.sent(),
                            [3, 3];
                        case 3:
                            return [2]
                        }
                    })
                })
            }
            ,
            r.prototype.sendFrameRequest = function(i) {
                return l(this, void 0, void 0, function() {
                    var t, n = this;
                    return R(this, function(e) {
                        return (t = this.window.document.createElement("iframe")).setAttribute("allow", ""),
                        t.width = "0",
                        t.height = "0",
                        t.style.display = "none",
                        t.setAttribute("aria-hidden", "true"),
                        t.title = "Criteo CSP Frame",
                        t.src = i,
                        this.window.document.body.appendChild(t),
                        setTimeout(function() {
                            return n.window.document.body.removeChild(t)
                        }, this.elementRemovalDelayMs),
                        [2]
                    })
                })
            }
            ;
            var o, p, U = r;
            function r(e, t, n) {
                void 0 === n && (n = window),
                this.pathName = "/api/csm/csp",
                this.defaultAllowedHostnames = ["criteo.com", "criteo.net", "crto.in", "localhost", "127.0.0.1"],
                this.allowedHostnames = c(this.defaultAllowedHostnames),
                this.elementRemovalDelayMs = 1e3,
                this.defaultFlushIntervalMs = 1e3,
                this.sentRequestLengthSoftLimit = 1e3,
                this.sentRequestLengthHardLimit = 6e3,
                this.events = [],
                this.partnerIds = void 0,
                this.clientRequestId = void 0,
                this.intervalHandle = 0,
                this.isRegistered = !1,
                this.window = n,
                this.backendHostname = e,
                this.callChainOrigin = t,
                this.setFlushInterval(this.defaultFlushIntervalMs)
            }
            function d(e, t) {
                var n = null == (n = window.Criteo) ? void 0 : n.oneTagConfig;
                return null != (n = n && n[e]) ? n : t
            }
            function W(e, t) {
                return "undefined" != typeof internalConfig ? internalConfig[e] : t
            }
            e.prototype.get = function() {
                return this.value
            }
            ,
            e.prototype.set = function(t) {
                var i = this
                  , o = function() {
                    return i.listeners.forEach(function(e) {
                        return e(t)
                    })
                };
                Array.isArray(t) && (t = new Proxy(t,{
                    get: function(e, t) {
                        return i.proxyArrayGet(e, t, o)
                    },
                    set: function(e, t, n) {
                        return i.proxyArraySet(e, t, n, o)
                    }
                })),
                this.value = t,
                o()
            }
            ,
            e.prototype.onPropertyChange = function(e) {
                e(this.value),
                this.listeners.push(e)
            }
            ,
            e.prototype.proxyArrayGet = function(i, o, r) {
                return "push" === o ? function() {
                    for (var e = [], t = 0; t < arguments.length; t++)
                        e[t] = arguments[t];
                    var n = i[o].apply(i, e);
                    return r(),
                    n
                }
                : i[o]
            }
            ,
            e.prototype.proxyArraySet = function(e, t, n, i) {
                return isNaN(Number(t)) ? e[t] = n : (e[t] = n,
                i()),
                !0
            }
            ;
            var N = e;
            function e(e) {
                this.listeners = [],
                this.value = e,
                this.set(e)
            }
            var h, V = "5.45.0", u = ((y = h = h || {})[y.None = 0] = "None",
            y[y.Cookie = 1] = "Cookie",
            y[y.LocalStorage = 2] = "LocalStorage",
            y[y.Library = 3] = "Library",
            n.checkLocalStorageIsWritable = function() {
                try {
                    var e, t, n;
                    return window.localStorage ? (e = "criteo_localstorage_check",
                    t = "test_value",
                    window.localStorage.setItem(e, t),
                    n = window.localStorage.getItem(e) === t,
                    window.localStorage.removeItem(e),
                    n) : !1
                } catch (e) {
                    return !1
                }
            }
            ,
            n.checkCookiesAreWritable = function() {
                var e = new n("criteo_write_test",1e4)
                  , t = (e.setValueWithNoDomain("1"),
                "1" === e.cookieValue);
                return e.removeWithNoDomain(),
                t
            }
            ,
            n.prototype.setCookieRead = function() {
                this.isCookieRead = !0
            }
            ,
            n.prototype.setValue = function(e, t) {
                void 0 === t && (t = !0),
                this.cookieValue = e,
                this.isCookieValueExternallySet = !0,
                t && this.writeOnAllStorages(e)
            }
            ,
            n.prototype.setValueFromExistingCookie = function() {
                var e = this.getValue();
                void 0 !== e && (this.cookieValue = e,
                this.cookieExtractor = {
                    origin: h.Cookie
                })
            }
            ,
            n.prototype.setValueFromAllStorages = function() {
                var e = this.getFromAllStorages();
                this.cookieValue = e.value,
                this.cookieExtractor = e.identifierExtractor
            }
            ,
            n.prototype.getValue = function() {
                for (var e = 0, t = document.cookie.split(";"); e < t.length; e++) {
                    var n = t[e];
                    if (n.substr(0, n.indexOf("=")).replace(/^\s+|\s+$/g, "") === this.cookieName)
                        return n = n.substr(n.indexOf("=") + 1),
                        (decodeURIComponent || unescape)(n)
                }
            }
            ,
            n.prototype.removeWithNoDomain = function() {
                this.setValueWithNoDomainWithExpiration("", 0)
            }
            ,
            n.prototype.removeOnMainDomain = function() {
                this.setOnMainDomainWithExpiration("", 0)
            }
            ,
            n.prototype.setOnMainDomain = function(e) {
                return this.setOnMainDomainWithExpiration(e, this.cookieRetentionTimeInMs)
            }
            ,
            n.prototype.writeOnAllStorages = function(e) {
                this.setOnMainDomain(e),
                this.tryWriteInLocalStorage(e)
            }
            ,
            n.prototype.getFromAllStorages = function() {
                switch (this.cookieExtractor.origin) {
                case h.LocalStorage:
                    return {
                        value: window.localStorage.getItem(this.cookieName),
                        identifierExtractor: {
                            origin: h.LocalStorage
                        }
                    };
                case h.Cookie:
                    return {
                        value: this.getValue(),
                        identifierExtractor: {
                            origin: h.Cookie
                        }
                    };
                case h.Library:
                    return {
                        value: null == (e = (t = this.cookieExtractor).retrievalMethod) ? void 0 : e.call(t),
                        identifierExtractor: {
                            origin: h.Library
                        }
                    };
                case h.None:
                    var e = this.tryReadFromLocalStorage()
                      , t = this.getValue() || null;
                    return {
                        value: t || e,
                        identifierExtractor: {
                            origin: this.computeStorageOrigin(t, e)
                        }
                    }
                }
            }
            ,
            n.prototype.removeFromAllStorages = function() {
                this.removeOnMainDomain(),
                this.tryRemoveFromLocalStorage()
            }
            ,
            n.prototype.setValueWithNoDomainWithExpiration = function(e, t) {
                var n = new Date
                  , t = (n.setTime(n.getTime() + t),
                "expires=" + n.toUTCString())
                  , n = encodeURIComponent || escape
                  , n = (document.cookie = this.cookieName + "=" + n(e) + ";" + t + ";path=/",
                this.getValue());
                void 0 !== n && (this.cookieValue = n)
            }
            ,
            n.prototype.setValueWithNoDomain = function(e) {
                this.setValueWithNoDomainWithExpiration(e, this.cookieRetentionTimeInMs)
            }
            ,
            n.prototype.toFragmentData = function() {
                return {
                    identifierExtractor: this.cookieExtractor,
                    value: this.cookieValue
                }
            }
            ,
            n.prototype.setOnMainDomainWithExpiration = function(e, t) {
                for (var n = new Date, i = (n.setTime(n.getTime() + t),
                "expires=" + n.toUTCString()), o = null === document.location ? [] : document.location.hostname.split("."), r = null, a = 0; a < o.length; ++a) {
                    var s = "domain=." + (r = o.slice(o.length - a - 1, o.length).join("."))
                      , c = encodeURIComponent || escape
                      , c = (document.cookie = this.cookieName + "=" + c(e) + ";" + i + ";" + s + ";path=/",
                    this.getValue());
                    if (c && c === e)
                        break
                }
                return r || document.location
            }
            ,
            n.prototype.computeStorageOrigin = function(e, t) {
                var n = h.None;
                return e && (n |= h.Cookie),
                t && (n |= h.LocalStorage),
                n
            }
            ,
            n.prototype.getMatchingKeyInAllStorage = function(e) {
                if (!(e instanceof RegExp))
                    return e;
                if ("undefined" != typeof localStorage)
                    for (var t = 0, n = Object.keys(localStorage); t < n.length; t++) {
                        var i = n[t];
                        if (e.test(i))
                            return i
                    }
                for (var o = 0, r = document.cookie.split(";"); o < r.length; o++) {
                    var a = r[o];
                    if (e.test(a))
                        return a
                }
                return ""
            }
            ,
            n.prototype.tryReadFromLocalStorage = function() {
                var e, t;
                try {
                    return null != (t = null == (e = window.localStorage) ? void 0 : e.getItem(this.cookieName)) ? t : null
                } catch (e) {
                    return null
                }
            }
            ,
            n.prototype.tryRemoveFromLocalStorage = function() {
                try {
                    return window.localStorage ? (window.localStorage.removeItem(this.cookieName),
                    !0) : !1
                } catch (e) {
                    return !1
                }
            }
            ,
            n.prototype.tryWriteInLocalStorage = function(e) {
                var t, n;
                try {
                    return null != (t = window.localStorage) && t.setItem(this.cookieName, e),
                    (null == (n = window.localStorage) ? void 0 : n.getItem(this.cookieName)) === e
                } catch (e) {
                    return !1
                }
            }
            ,
            n);
            function n(e, t, n) {
                void 0 === n && (n = {
                    origin: h.None
                }),
                this.cookieValue = null,
                this.isCookieValueExternallySet = !1,
                this.isCookieRead = !1,
                this.cookieName = this.getMatchingKeyInAllStorage(e),
                this.cookieRetentionTimeInMs = t,
                this.cookieExtractor = n
            }
            var f, H = "OneTag", q = ["color: #fff;", "background: #ff4f00;", "display: inline-block;", "padding: 1px 4px;", "border-radius: 3px;"].join(" "), F = ((y = f = f || {})[y.Off = 0] = "Off",
            y[y.Error = 1] = "Error",
            y[y.Warning = 2] = "Warning",
            y[y.Info = 3] = "Info",
            y[y.Debug = 4] = "Debug",
            i.setLogLevel = function(e) {
                i.level = e,
                this.debug("Log level set to " + f[e])
            }
            ,
            i.setUseHeader = function(e) {
                this.useHeader = e
            }
            ,
            i.debug = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                i.log(console.log, f.Debug, e)
            }
            ,
            i.info = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                i.log(console.log, f.Info, e)
            }
            ,
            i.warn = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                i.log(console.warn, f.Warning, e)
            }
            ,
            i.error = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                i.log(console.error, f.Error, e)
            }
            ,
            i.log = function(e, t, n) {
                t <= i.level && (t = 0 < (t = window.navigator.userAgent).indexOf("MSIE ") || 0 < t.indexOf("Trident/") ? ["[" + H + "]"] : ["%c" + H, q],
                e.apply(console, this.useHeader ? t.concat(n) : n))
            }
            ,
            i.level = f.Warning,
            i.useHeader = !0,
            i);
            function i() {}
            t.prototype.catchAndStoreException = function(i, o) {
                return l(this, void 0, void 0, function() {
                    var t, n;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return (e.trys.push([0, 3, , 4]),
                            (t = (t = void 0) === o ? i() : i.apply(this, o))instanceof Promise) ? [4, t] : [3, 2];
                        case 1:
                            return [2, e.sent()];
                        case 2:
                            return [2, t];
                        case 3:
                            return n = e.sent(),
                            n = n instanceof Error ? n : new Error(n),
                            this.exceptions.push(n),
                            [3, 4];
                        case 4:
                            return [2, void 0]
                        }
                    })
                })
            }
            ,
            t.prototype.setProtectedTimeout = function(e, t) {
                var n = this;
                if ("undefined" != typeof window && "function" == typeof window.setTimeout)
                    return window.setTimeout(function() {
                        return n.catchAndStoreException(e)
                    }, t)
            }
            ,
            t.prototype.addProtectedEventListener = function(e, t, n, i) {
                var o = this;
                if (void 0 !== e && "function" == typeof e.addEventListener)
                    return e.addEventListener(t, function() {
                        for (var e = [], t = 0; t < arguments.length; t++)
                            e[t] = arguments[t];
                        return o.catchAndStoreException(n, e)
                    }, i)
            }
            ,
            t.prototype.attachProtectedEvent = function(e, t, n) {
                var i = this;
                if (void 0 !== e && "function" == typeof e.attachEvent)
                    return e.attachEvent(t, function() {
                        for (var e = [], t = 0; t < arguments.length; t++)
                            e[t] = arguments[t];
                        return i.catchAndStoreException(n, e)
                    })
            }
            ;
            var G = t;
            function t() {
                this.exceptions = []
            }
            m.prototype.preload = function() {
                var t = this;
                this.onUserIdAvailable(function(e) {
                    t.logger("preload complete, userId:", e)
                }, m.maxWaitForApiMs)
            }
            ,
            m.prototype.onUserIdAvailable = function(i, o) {
                function r(e) {
                    var t, n;
                    s || (t = e * m.retryIntervalMs,
                    void 0 !== (n = a.instance()) ? (s = !0,
                    n.onUpdate(function(e) {
                        e = e.getUserId();
                        return a.logger("user ID available:", e),
                        void 0 !== e && localStorage.setItem(m.localStorageKey, e),
                        i(e)
                    })) : o <= t ? (s = !0,
                    a.logger("timeout waiting for instance after waiting (ms):", t),
                    i(void 0)) : (a.exceptionHandler.setProtectedTimeout(function() {
                        return r(e)
                    }, m.retryIntervalMs),
                    e++))
                }
                var a = this
                  , s = !1;
                return r(0),
                this
            }
            ,
            m.prototype.instance = function() {
                var e;
                return void 0 === this._instance && window.hasOwnProperty("Criteo") && null != (e = window.Criteo) && e.hasOwnProperty("ID5") && (e = void 0,
                e = this.useStaticConsentForId5 ? {
                    partnerId: m.criteoPartnerId,
                    cmpApi: "static",
                    consentData: {
                        allowedVendors: ["131", "91"]
                    }
                } : {
                    partnerId: m.criteoPartnerId
                },
                this._instance = window.Criteo.ID5.init(e)),
                this._instance
            }
            ,
            m.prototype.getUserId = function() {
                var e = this.instance();
                if (void 0 !== e) {
                    e = e.getUserId();
                    if (void 0 !== e)
                        return this.logger("[getUserId] from API ", e),
                        e
                }
                e = localStorage.getItem(m.localStorageKey);
                if (null !== e)
                    return this.logger("[getUserId] from local storage ", e),
                    e
            }
            ,
            m.prototype.initialize = function() {
                (e = document.createElement("iframe")).style.display = "none",
                document.body.appendChild(e);
                var e, t, n, i, o = e;
                e = "https://cdn.id5-sync.com/api/1.0/id5-api.js",
                t = o,
                n = function() {
                    window.Criteo = window.Criteo || {},
                    window.Criteo.ID5 = o.contentWindow.ID5
                }
                ,
                (i = document.createElement("script")).src = e,
                i.type = "text/javascript",
                i.onload = n,
                null != (e = t.contentWindow) && e.document.head.appendChild(i),
                this.preload()
            }
            ,
            m.criteoPartnerId = 203,
            m.retryIntervalMs = 100,
            m.maxWaitForApiMs = 2e4,
            m.localStorageKey = "criteo-id5id-fast-track";
            var j = m;
            function m(e) {
                this.useStaticConsentForId5 = e,
                this.logger = function() {
                    for (var e = [], t = 0; t < arguments.length; t++)
                        e[t] = arguments[t];
                    return F.debug.apply(F, c(["[ID5]"], e))
                }
                ,
                this.exceptionHandler = new G
            }
            a.prototype.isStepAllowed = function(t) {
                return !this.blockedSteps.some(function(e) {
                    return e == t
                })
            }
            ,
            Object.defineProperty(a.prototype, "account", {
                get: function() {
                    return this.observableAccounts.get()
                },
                set: function(e) {
                    this.observableAccounts.set(e)
                },
                enumerable: !1,
                configurable: !0
            }),
            a.prototype.onAccountChange = function(e) {
                this.observableAccounts.onPropertyChange(e)
            }
            ;
            var Q = a;
            function a() {
                this.firstPartyIdentifier = d("fpIdentifier") || null,
                this.customerInfo = [],
                this.extraData = [],
                this.handlerParams = {
                    v: V
                },
                this.handlerResponseType = "single",
                this.handlerUrlPrefix = "https://sslwidget.criteo.com/event",
                this.partnerPayload = null,
                this.requestType = "pixel",
                this.responseType = "js",
                this.tagVersion = V,
                this.dynamic = d("dynamic") || null,
                this.fullUrlMaxLength = d("fullUrlMaxLength", 4e3),
                this.previousUrlMaxLength = d("previousUrlMaxLength", 400),
                this.privateModeDetectionEnabled = d("privateModeDetectionEnabled", !0),
                this.blockedSteps = d("blockedSteps", []),
                this.excludedReferrerParams = d("excludedReferrerParams", []),
                this.observableAccounts = new N(d("partnerId") || null)
            }
            s.prototype.getReadyToRetrieveProvider = function() {
                return this.tcfv2ConsentProvider.hasCallerFunctionInFrame() ? this.tcfv2ConsentProvider : this.tcfv1ConsentProvider.hasCallerFunctionInFrame() ? this.tcfv1ConsentProvider : void 0 !== this.tcfv2ConsentProvider.getCMPFrame() ? this.tcfv2ConsentProvider : void 0 !== this.tcfv1ConsentProvider.getCMPFrame() ? this.tcfv1ConsentProvider : void 0
            }
            ,
            s.prototype.retrieveConsentForPassback = function(e) {
                var t = this.getReadyToRetrieveProvider();
                void 0 === t && (this.logger("No compatible GDPR privacy provider found"),
                e(void 0)),
                t === this.tcfv1ConsentProvider ? this.tcfv1ConsentProvider.retrieveConsentForPassback(e) : t === this.tcfv2ConsentProvider && this.tcfv2ConsentProvider.retrieveConsent(e)
            }
            ,
            s.prototype.retrieveConsent = function(e) {
                var t = this.getReadyToRetrieveProvider();
                void 0 === t && (this.logger("No compatible GDPR privacy provider found"),
                e(void 0)),
                null != t && t.retrieveConsent(e)
            }
            ,
            s.prototype.readyToRetrieve = function() {
                return this.tcfv2ConsentProvider.readyToRetrieve() || this.tcfv1ConsentProvider.readyToRetrieve()
            }
            ;
            var B = s;
            function s(e, t, n) {
                void 0 === n && (n = function(e) {}
                ),
                this.tcfv1ConsentProvider = e,
                this.tcfv2ConsentProvider = t,
                this.logger = n
            }
            function z(e) {
                try {
                    return JSON.parse(e)
                } catch (e) {}
            }
            g.prototype.getCMPFrame = function() {
                for (var e, t = this.currentWindow, n = 0; n < 10; ++n) {
                    try {
                        t.frames.__cmpLocator && (e = t)
                    } catch (e) {}
                    if (t === this.currentWindow.top)
                        break;
                    t = t.parent
                }
                return e
            }
            ,
            g.prototype.hasCallerFunctionInFrame = function() {
                return "function" == typeof this.currentWindow.__cmp
            }
            ,
            g.prototype.readyToRetrieve = function() {
                return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame()
            }
            ,
            g.prototype.pingWithTimeout = function(i, e, t, n) {
                function o(e, t) {
                    r.logger(t),
                    clearTimeout(e),
                    n()
                }
                var r = this;
                return window.setTimeout(function() {
                    var n = window.setTimeout(function() {
                        o(i, "Timeout: Unable to get ping return after " + e + "ms")
                    }, e);
                    r.executeCommand("ping", null, function(e, t) {
                        clearTimeout(n),
                        t ? (r.logger("GDPR CMP ping returned"),
                        !0 !== e.cmpLoaded && o(i, "GDPR ping returned cmpLoaded which is not true"),
                        r.logger("GDPR ping returned cmpLoaded which is true")) : o(i, "Error sending ping to GDPR CMP")
                    })
                }, t)
            }
            ,
            g.prototype.retrieveConsent = function(e) {
                this.executeRetrieveConsent("getConsentData", null, e)
            }
            ,
            g.prototype.retrieveConsentForPassback = function(e) {
                this.executeRetrieveConsent("getVendorConsents", [91], e)
            }
            ,
            g.prototype.executeRetrieveConsent = function(e, t, n) {
                var i = this
                  , o = !1
                  , r = window.setTimeout(function() {
                    o = !0,
                    i.logger("Timeout: Unable to resolve GDPR consent after " + i.timeout + "ms"),
                    n(void 0)
                }, this.timeout)
                  , a = !1 !== this.cmpAutoDetect ? this.pingWithTimeout(r, this.pingTimeout, this.pingDelay, function() {
                    o = !0,
                    i.logger("Timeout: Unable to ping GDPR API after " + i.pingTimeout + "ms"),
                    n(void 0)
                }) : void 0;
                this.executeCommand(e, t, function(e, t) {
                    clearTimeout(a),
                    o || (clearTimeout(r),
                    t ? (i.logger("GDPR consent retrieved"),
                    i.processConsentData(e, n)) : (i.logger("Error retrieving GDPR consent data from CMP"),
                    n(void 0)))
                })
            }
            ,
            g.prototype.processConsentData = function(e, t) {
                var n;
                e ? (n = {},
                "undefined" === e.consentData && (e.consentData = ""),
                n.consentData = void 0 !== e.consentData ? e.consentData : "",
                void 0 !== e.gdprApplies && (n.gdprApplies = !!e.gdprApplies),
                t(n)) : (this.logger("Unable to read GDPR consent data from CMP"),
                t(void 0))
            }
            ,
            g.prototype.executeCommand = function(e, t, n) {
                var i, o = this;
                this.hasCallerFunctionInFrame() || (this.logger("No GDPR CMP defined on current frame"),
                i = this.getCMPFrame(),
                this.currentWindow.__cmp = function(e, t, n) {
                    i ? (t = {
                        __cmpCall: {
                            command: e,
                            parameter: t,
                            callId: e = Math.random().toString(10)
                        }
                    },
                    o.cmpCallbacks[e] = n,
                    i.postMessage(t, "*")) : (o.logger("GDPR CMP not found in any frame"),
                    n({
                        msg: "GDPR CMP not found in any frame"
                    }, !1))
                }
                ,
                this.currentWindow.addEventListener("message", function(e) {
                    var e = "string" == typeof e.data ? z(e.data) : e.data;
                    e && e.__cmpReturn && e.__cmpReturn.callId && e.__cmpReturn.returnValue && (e = e.__cmpReturn,
                    o.cmpCallbacks) && o.cmpCallbacks[e.callId] && (o.cmpCallbacks[e.callId](e.returnValue, e.success),
                    delete o.cmpCallbacks[e.callId])
                }, !1)),
                this.currentWindow.__cmp(e, t, n)
            }
            ;
            var J = g;
            function g(e, t, n) {
                void 0 === n && (n = function(e) {}
                ),
                this.cmpCallbacks = {},
                this.currentWindow = e,
                this.timeout = t.tcfTimeout,
                this.pingTimeout = t.tcfPingTimeout,
                this.pingDelay = t.tcfPingDelay,
                this.cmpAutoDetect = t.cmpAutoDetect,
                this.logger = n
            }
            (y = v = v || {}).LOADED = "tcloaded",
            y.UI_SHOWN = "cmpuishown",
            y.USER_ACTION_COMPLETE = "useractioncomplete",
            C.prototype.getCMPFrame = function() {
                for (var e, t = this.currentWindow, n = 0; n < 10; ++n) {
                    try {
                        t.frames.__tcfapiLocator && (e = t)
                    } catch (e) {}
                    if (t === this.currentWindow.top)
                        break;
                    t = t.parent
                }
                return e
            }
            ,
            C.prototype.hasCallerFunctionInFrame = function() {
                return "function" == typeof this.currentWindow.__tcfapi
            }
            ,
            C.prototype.readyToRetrieve = function() {
                return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame()
            }
            ,
            C.prototype.pingWithTimeout = function(n, e, t, i) {
                function o(e, t) {
                    r.logger(t),
                    clearTimeout(e),
                    i()
                }
                var r = this;
                return window.setTimeout(function() {
                    var t = window.setTimeout(function() {
                        o(n, "Timeout: Unable to get TCFv2 ping return after " + e + "ms")
                    }, e);
                    r.executeCommand("ping", 2, function(e) {
                        clearTimeout(t),
                        r.logger("TCFv2 CMP ping returned in ms"),
                        "error" === e.cmpStatus ? o(n, "Error status on ping to TCFv2 CMP") : !0 !== e.cmpLoaded ? o(n, "TCFv2 ping returned cmpLoaded = false") : r.logger("TCFv2 ping returned cmpLoaded = true")
                    })
                }, t)
            }
            ,
            C.prototype.retrieveConsent = function(n) {
                var i, o, r = this, a = !1, s = window.setTimeout(function() {
                    a = !0,
                    o === v.UI_SHOWN ? (r.logger("Timeout: User hasn't confirm their consent settings after " + r.timeout + "ms"),
                    n(i)) : (r.logger("Timeout: Unable to resolve TCFv2 consent after " + r.timeout + "ms"),
                    n(void 0))
                }, this.timeout), c = !1 !== this.cmpAutoDetect ? this.pingWithTimeout(s, this.pingTimeout, this.pingDelay, function() {
                    a = !0,
                    r.logger("Timeout: Unable to ping TCFv2 API after " + r.pingTimeout + "ms"),
                    n(void 0)
                }) : void 0;
                this.executeCommand("addEventListener", 2, function(e, t) {
                    clearTimeout(c),
                    a || ((o = e.eventStatus) !== v.UI_SHOWN && clearTimeout(s),
                    t ? (r.logger("TCFv2 consent retrieved in ms"),
                    e || (r.logger("Unable to read GDPR consent data from CMP"),
                    n(void 0)),
                    i = r.processResponseData(e),
                    (!1 === e.gdprApplies && void 0 === o || o === v.LOADED || o === v.USER_ACTION_COMPLETE) && n(i)) : (r.logger("Error retrieving TCFv2 consent data from CMP"),
                    n(void 0)))
                })
            }
            ,
            C.prototype.processResponseData = function(e) {
                var t, n = {};
                return "undefined" === e.tcString && (e.tcString = ""),
                n.consentData = void 0 !== e.tcString ? e.tcString : "",
                void 0 !== e.gdprApplies && (n.gdprApplies = !!e.gdprApplies),
                n.version = e.tcfPolicyVersion || 2,
                n.purposes = null == (t = null == e ? void 0 : e.purpose) ? void 0 : t.consents,
                n.vendorConsents = null == (t = null == e ? void 0 : e.vendor) ? void 0 : t.consents,
                n
            }
            ,
            C.prototype.executeCommand = function(e, t, n, i) {
                var o, r = this;
                this.hasCallerFunctionInFrame() || (this.logger("No TCFv2 CMP defined on current frame"),
                o = this.getCMPFrame(),
                this.currentWindow.__tcfapi = function(e, t, n, i) {
                    o ? (t = {
                        __tcfapiCall: {
                            command: e,
                            version: t,
                            parameter: i,
                            callId: e = Math.random().toString(10)
                        }
                    },
                    r.cmpCallbacks[e] = n,
                    o.postMessage(t, "*")) : (r.logger("TCFv2 CMP not found in any frame"),
                    n({
                        msg: "TCFv2 CMP not found in any frame"
                    }, !1))
                }
                ,
                this.currentWindow.addEventListener("message", function(e) {
                    var e = "string" == typeof e.data ? z(e.data) : e.data;
                    e && e.__tcfapiReturn && e.__tcfapiReturn.callId && e.__tcfapiReturn.returnValue && (e = e.__tcfapiReturn,
                    r.cmpCallbacks) && r.cmpCallbacks[e.callId] && "function" == typeof r.cmpCallbacks[e.callId] && (r.cmpCallbacks[e.callId](e.returnValue, e.success),
                    e.returnValue.eventStatus !== v.UI_SHOWN) && delete r.cmpCallbacks[e.callId]
                }, !1)),
                this.currentWindow.__tcfapi(e, t, n, i)
            }
            ;
            var v, y, K = C;
            function C(e, t, n) {
                void 0 === n && (n = function(e) {}
                ),
                this.cmpCallbacks = {},
                this.currentWindow = e,
                this.timeout = t.tcfTimeout,
                this.pingTimeout = t.tcfPingTimeout,
                this.pingDelay = t.tcfPingDelay,
                this.cmpAutoDetect = t.cmpAutoDetect,
                this.logger = n
            }
            w.prototype.getCMPFrame = function() {
                for (var e, t = this.currentWindow, n = 0; n < 10; ++n) {
                    try {
                        t.frames.__uspapiLocator && (e = t)
                    } catch (e) {}
                    if (t === this.currentWindow.top)
                        break;
                    t = t.parent
                }
                return e
            }
            ,
            w.prototype.hasCallerFunctionInWindow = function() {
                return "function" == typeof this.currentWindow.__uspapi
            }
            ,
            w.prototype.readyToRetrieve = function() {
                return this.hasCallerFunctionInWindow() || void 0 !== this.getCMPFrame()
            }
            ,
            w.prototype.retrieveConsent = function(n) {
                var i = this
                  , o = !1
                  , r = window.setTimeout(function() {
                    o = !0,
                    i.logger("Timeout: Unable to resolve CCPA consent after " + i.timeout + "ms"),
                    n(void 0)
                }, this.timeout);
                this.executeCommand("getUSPData", 1, function(e, t) {
                    o || (clearTimeout(r),
                    t ? (i.logger("CCPA consent retrieved"),
                    i.processResponseData(e, n)) : (i.logger("Error retrieving CCPA consent data from CMP"),
                    n(void 0)))
                })
            }
            ,
            w.prototype.processResponseData = function(e, t) {
                e ? t(e) : (this.logger("Unable to read CCPA consent data from CMP"),
                t(void 0))
            }
            ,
            w.prototype.executeCommand = function(e, t, n) {
                var i, o = this;
                this.hasCallerFunctionInWindow() || (this.logger("No CCPA CMP defined on current frame"),
                i = this.getCMPFrame(),
                this.currentWindow.__uspapi = function(e, t, n) {
                    i ? (t = {
                        __uspapiCall: {
                            command: e,
                            parameter: t,
                            callId: e = Math.random().toString(10)
                        }
                    },
                    o.uspapiCallbacks[e] = n,
                    i.postMessage(t, "*")) : (o.logger("CCPA CMP not found in any frame"),
                    n({
                        msg: "CCPA CMP not found in any frame"
                    }, !1))
                }
                ,
                this.currentWindow.addEventListener("message", function(e) {
                    var e = "string" == typeof e.data ? z(e.data) : e.data;
                    e && e.__uspapiReturn && e.__uspapiReturn.callId && e.__uspapiReturn.returnValue && (e = e.__uspapiReturn,
                    o.uspapiCallbacks) && o.uspapiCallbacks[e.callId] && (o.uspapiCallbacks[e.callId](e.returnValue, e.success),
                    delete o.uspapiCallbacks[e.callId])
                }, !1)),
                this.currentWindow.__uspapi(e, t, n)
            }
            ,
            w.prototype.hasUserOptOut = function(e) {
                return !(!e || !e.uspString || "1YNY" === e.uspString.toUpperCase() || "1YNN" === e.uspString.toUpperCase() || "1YN-" === e.uspString.toUpperCase() || "1-N-" === e.uspString.toUpperCase() || "1-NN" === e.uspString.toUpperCase() || "1-NY" === e.uspString.toUpperCase() || "1---" === e.uspString)
            }
            ;
            var Y = w;
            function w(e, t, n) {
                void 0 === n && (n = function(e) {}
                ),
                this.uspapiCallbacks = {},
                this.currentWindow = e,
                this.timeout = t.uspApiTimeout,
                this.logger = n
            }
            b.prototype.getCMPFrame = function() {
                for (var e, t = this.currentWindow, n = 0; n < 10; ++n) {
                    try {
                        void 0 !== t && t.frames.__gppLocator && (e = t)
                    } catch (e) {}
                    if (t === this.currentWindow.top)
                        break;
                    t = t.parent
                }
                return e
            }
            ,
            b.prototype.hasCallerFunctionInFrame = function() {
                return "function" == typeof this.currentWindow.__gpp
            }
            ,
            b.prototype.readyToRetrieve = function() {
                return this.hasCallerFunctionInFrame() || void 0 !== this.getCMPFrame()
            }
            ,
            b.prototype.retrieveConsent = function(n) {
                function i(e, t) {
                    o.logger(t),
                    clearTimeout(e),
                    r = !0,
                    o.logger("Timeout: Unable to ping GPP after " + o.pingTimeout + "ms"),
                    n(void 0)
                }
                var o = this
                  , r = !1
                  , a = window.setTimeout(function() {
                    r = !0,
                    o.logger("Timeout: Unable to resolve GPP consent after " + o.timeout + "ms"),
                    n(void 0)
                }, this.timeout);
                window.setTimeout(function() {
                    var t = window.setTimeout(function() {
                        i(a, "Timeout: Unable to get GPP ping return after " + o.pingTimeout + "ms")
                    }, o.pingTimeout);
                    o.executeCommand("ping", function(e) {
                        clearTimeout(t),
                        o.logger("GPP CMP ping has responsed"),
                        "1.0" === e.gppVersion ? (o.logger("Detected GPP CMP 1.0"),
                        "error" === e.cmpStatus ? i(a, "Error status on ping to GPP CMP") : "loaded" === e.cmpStatus ? (o.logger("GPP ping returned cmpStatus = loaded"),
                        o.executeCommand("getGPPData", function(e, t) {
                            r || (clearTimeout(a),
                            t ? (o.logger("GPP consent retrieved"),
                            o.processResponseData(e, n)) : (o.logger("Error retrieving GPP consent data from CMP"),
                            n(void 0)))
                        })) : i(a, "GPP ping returned cmpStatus != loaded")) : "1.1" === e.gppVersion ? (o.logger("Detected GPP CMP 1.1"),
                        "ready" === e.signalStatus ? (clearTimeout(a),
                        o.logger("GPP consent retrieved"),
                        o.processResponseData(e, n)) : o.executeCommand("addEventListener", function(e, t) {
                            r || "signalStatus" === e.eventName && "ready" === e.pingData.signalStatus && (clearTimeout(a),
                            o.logger("GPP consent retrieved"),
                            o.processResponseData(e.pingData, n))
                        })) : i(a, "Unknown GPP version " + e.gppVersion)
                    })
                }, this.pingDelay)
            }
            ,
            b.prototype.processResponseData = function(e, t) {
                var n;
                e ? (n = {},
                void 0 !== e.gppString && (n.gpp = e.gppString),
                void 0 !== e.applicableSections && (n.gppSid = e.applicableSections),
                t(n)) : (this.logger("Unable to read GPP consent data from CMP"),
                t(void 0))
            }
            ,
            b.prototype.executeCommand = function(e, t, n) {
                var i, o = this;
                this.hasCallerFunctionInFrame() || (this.logger("No GPP CMP defined on current frame"),
                i = this.getCMPFrame(),
                this.currentWindow.__gpp = function(e, t, n) {
                    i ? (n = {
                        __gppCall: {
                            command: e,
                            parameter: n,
                            callId: e = Math.random().toString(10)
                        }
                    },
                    o.cmpCallbacks[e] = t,
                    i.postMessage(n, "*")) : (o.logger("GPP CMP not found in any frame"),
                    t({
                        msg: "GPP CMP not found in any frame"
                    }, !1))
                }
                ,
                this.currentWindow.addEventListener("message", function(e) {
                    var e = "string" == typeof e.data ? z(e.data) : e.data;
                    e && e.__gppReturn && e.__gppReturn.callId && e.__gppReturn.returnValue && (e = e.__gppReturn,
                    o.cmpCallbacks) && o.cmpCallbacks[e.callId] && "function" == typeof o.cmpCallbacks[e.callId] && (o.cmpCallbacks[e.callId](e.returnValue, e.success),
                    delete o.cmpCallbacks[e.callId])
                }, !1)),
                this.currentWindow.__gpp(e, t, n)
            }
            ;
            var $ = b;
            function b(e, t, n) {
                void 0 === n && (n = function(e) {}
                ),
                this.cmpCallbacks = {},
                this.currentWindow = e,
                this.timeout = t.gppTimeout,
                this.pingTimeout = t.gppPingTimeout,
                this.pingDelay = t.gppPingDelay,
                this.logger = n
            }
            k.prototype.getLast = function() {
                return l(this, void 0, void 0, function() {
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this.hasValue];
                        case 1:
                            return e.sent(),
                            [2, this.lastValue]
                        }
                    })
                })
            }
            ,
            k.prototype.set = function(e) {
                this.lastValue = e,
                this.resolveHasValue()
            }
            ,
            k.unsetValue = {};
            var X = k;
            function k() {
                var t = this;
                this.lastValue = k.unsetValue,
                this.hasValue = new Promise(function(e) {
                    return t.resolveHasValue = e
                }
                )
            }
            ee.prototype.retrieveConsent = function() {
                return this.consentWrapper.getLast()
            }
            ,
            ee.prototype.updateConsent = function() {
                return l(this, void 0, void 0, function() {
                    var t, n, i, o, r, a = this;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return t = this.tcfCompatibleConsentProvider.readyToRetrieve(),
                            n = this.ccpaConsentProvider.readyToRetrieve(),
                            i = this.gppConsentProvider.readyToRetrieve(),
                            o = {},
                            r = [],
                            t && r.push(new Promise(function(t) {
                                a.tcfCompatibleConsentProvider.retrieveConsent(function(e) {
                                    o.gdprConsent = e,
                                    t()
                                })
                            }
                            )),
                            n && r.push(new Promise(function(t) {
                                a.ccpaConsentProvider.retrieveConsent(function(e) {
                                    o.ccpaConsent = e,
                                    t()
                                })
                            }
                            )),
                            i && r.push(new Promise(function(t) {
                                a.gppConsentProvider.retrieveConsent(function(e) {
                                    o.gppConsent = e,
                                    t()
                                })
                            }
                            )),
                            [4, Promise.all(r)];
                        case 1:
                            return e.sent(),
                            this.consentWrapper.set(o),
                            [2]
                        }
                    })
                })
            }
            ;
            var Z = ee;
            function ee(e, t) {
                var n = this
                  , t = void 0 === t ? {} : t
                  , i = t.timeout
                  , i = void 0 === i ? 1e4 : i
                  , o = t.pingTimeout
                  , o = void 0 === o ? 50 : o
                  , r = t.pingDelay
                  , r = void 0 === r ? 1e3 : r
                  , a = t.uspApiTimeout
                  , t = t.updateIntervalMs
                  , t = void 0 === t ? 1e3 : t
                  , s = {
                    tcfTimeout: i,
                    tcfPingTimeout: o,
                    tcfPingDelay: r
                }
                  , a = {
                    uspApiTimeout: void 0 === a ? 500 : a
                }
                  , i = {
                    gppTimeout: i,
                    gppPingTimeout: o,
                    gppPingDelay: r
                };
                this.tcfCompatibleConsentProvider = new B(new J(e,s,F.info),new K(e,s,F.info),F.info),
                this.ccpaConsentProvider = new Y(e,a,F.info),
                this.gppConsentProvider = new $(e,i,F.info),
                this.consentWrapper = new X,
                this.updateConsent(),
                e.setInterval(function() {
                    return n.updateConsent()
                }, t)
            }
            function te(e, t, n) {
                if (void 0 === n && (n = void 0),
                e instanceof Array)
                    for (var i = 0, o = e; i < o.length; i++)
                        te(o[i], t, n);
                else {
                    e = void 0 !== n ? n(e) : e;
                    void 0 === e || ne(t, e) || t.push(e)
                }
            }
            function ne(e, t) {
                for (var n = JSON.stringify || encodeURIComponent || escape, i = n(t), o = 0, r = e; o < r.length; o++) {
                    var a = r[o];
                    if (a === t || n(a) === i)
                        return 1
                }
            }
            function ie(e) {
                for (var t = [], n = 0, i = e; n < i.length; n++) {
                    var o = i[n];
                    null != o && t.push(o)
                }
                return t
            }
            function P(e, t) {
                if (void 0 !== e || void 0 !== t) {
                    if (void 0 === e || void 0 === t)
                        return !1;
                    if (!(e instanceof Array))
                        return P([e], t);
                    if (!(t instanceof Array))
                        return P(e, [t]);
                    if (e.length !== t.length)
                        return !1;
                    for (var n = 0, i = e; n < i.length; n++)
                        if (!ne(t, i[n]))
                            return !1
                }
                return !0
            }
            I.extractHostname = function(e) {
                var t = document.createElement("a");
                return t.href = e,
                t.hostname
            }
            ,
            I.getAnchorWithReferrer = function(e) {
                var t;
                return e && e.referrer ? ((t = e.createElement("a")).href = e.referrer,
                t) : null
            }
            ,
            I.getQueryString = function(t) {
                var n;
                try {
                    n = t.top.location.search
                } catch (e) {
                    var i = t;
                    try {
                        for (; i.parent.document !== i.document && i.parent.document; )
                            i = i.parent
                    } catch (e) {}
                    i && (t = I.getAnchorWithReferrer(i.document)) && (n = t.search)
                }
                return n
            }
            ,
            I.getHighestAccessibleUrl = function(e) {
                try {
                    var t = e.top.location.href;
                    if (t)
                        return t
                } catch (e) {}
                return I.getHighestAccessibleWindow(e).topFrame.location.href
            }
            ,
            I.getPreviousUrl = function(e) {
                var e = I.getHighestAccessibleWindow(e)
                  , t = e.topFrame
                  , n = "";
                return (n = e.err ? n : t.document.referrer || (null == (e = t.top) ? void 0 : e.document.referrer) || "") || (t = null == (e = t.location) ? void 0 : e.ancestorOrigins) && 0 < t.length && (n = t[t.length - 1]),
                n
            }
            ,
            I.onBodyReady = function(t, n) {
                !function e() {
                    document.body ? t.setProtectedTimeout(n, 0) : t.setProtectedTimeout(e, 10)
                }()
            }
            ,
            I.onDocumentReady = function(n, i) {
                if ("complete" === document.readyState)
                    n.catchAndStoreException(i);
                else if (document.addEventListener)
                    n.addProtectedEventListener(document, "DOMContentLoaded", i, !1),
                    n.addProtectedEventListener(window, "load", i, !1);
                else {
                    n.attachProtectedEvent(document, "onreadystatechange", i),
                    n.attachProtectedEvent(window, "onload", i);
                    var t, o, r, e = !1;
                    try {
                        e = null === window.frameElement && document.documentElement
                    } catch (e) {}
                    e && e.doScroll ? function t() {
                        if (e) {
                            try {
                                e.doScroll("left")
                            } catch (e) {
                                return void n.setProtectedTimeout(t, 50)
                            }
                            n.catchAndStoreException(i)
                        }
                    }() : (t = !1,
                    o = null === document.onload ? null : function(e, t) {
                        return e.onload(t)
                    }
                    ,
                    r = null === document.onreadystatechange ? null : function(e, t) {
                        return e.onreadystatechange(t)
                    }
                    ,
                    document.onload = document.onreadystatechange = function(e) {
                        r instanceof Function && r(document, e),
                        t || document.readyState && "complete" !== document.readyState || (o instanceof Function && o(document, e),
                        t = !0,
                        n.catchAndStoreException(i))
                    }
                    )
                }
            }
            ,
            I.removeLater = function(e, t) {
                e.setProtectedTimeout(function() {
                    var e;
                    return null == (e = null == t ? void 0 : t.parentElement) ? void 0 : e.removeChild(t)
                }, 3e4)
            }
            ,
            I.appendCriteoContainer = function(e) {
                var t;
                return e ? ((t = document.createElement("div")).setAttribute("id", "criteo-tags-div"),
                t.style.display = "none",
                e.appendChild(t),
                t) : null
            }
            ,
            I.getHighestAccessibleWindow = function(e) {
                var t = e
                  , n = !1;
                try {
                    for (; t.parent.document !== t.document; ) {
                        if (!t.parent.document) {
                            n = !0;
                            break
                        }
                        t = t.parent
                    }
                } catch (e) {
                    n = !0
                }
                return {
                    topFrame: t,
                    err: n
                }
            }
            ;
            var S = I;
            function I() {}
            function D(e) {
                var t = e;
                if (e instanceof Function)
                    return (t = e())instanceof Function ? t : D(t);
                if (e instanceof Array)
                    for (var t = [], n = 0; n < e.length; ++n)
                        t[n] = D(e[n]);
                else if (e && "[object Object]" === e.toString()) {
                    t = {};
                    for (var i = 0, o = Object.getOwnPropertyNames(e); i < o.length; i++) {
                        var r = o[i];
                        t[r] = D(e[r])
                    }
                }
                return t
            }
            function oe(e, t) {
                for (var n = 0, i = e; n < i.length; n++) {
                    var o = i[n];
                    if (o.event === t.event && P(t.account, o.account)) {
                        for (var r in t)
                            t.hasOwnProperty(r) && "account" !== r && (o[r] = t[r]);
                        return
                    }
                }
                e.push(t)
            }
            function re(e, t) {
                for (var n = 0, i = e; n < i.length; n++) {
                    var o = i[n];
                    if (o.event === t.event && P(t.account, o.account) && o.hash_method === t.hash_method)
                        return void (void 0 !== t.email && (o.email = function(e, t) {
                            var n = [];
                            if (void 0 === e)
                                return void 0 === t ? n : t.slice();
                            if (void 0 === t)
                                return e.slice();
                            for (var i = 0, o = t; i < o.length; i++) {
                                var r = o[i];
                                ne(e, r) || n.push(r)
                            }
                            return e.concat(n)
                        }(o.email instanceof Array || void 0 === o.email ? o.email : [o.email], t.email instanceof Array ? t.email : [t.email])))
                }
                e.push(t)
            }
            function T(e, t, n) {
                n = D(n);
                return ae(e, n),
                oe(t, D(n)),
                1
            }
            function ae(e, t) {
                for (var n = 0, i = e; n < i.length; n++) {
                    var o = i[n];
                    if (o.event === t.event && void 0 === t.account && void 0 === o.account || P(t.account, o.account)) {
                        for (var r in t)
                            t.hasOwnProperty(r) && "account" !== r && (o[r] = t[r]);
                        return
                    }
                }
                e.push(t)
            }
            ce.prototype.acquire = function() {
                return l(this, void 0, void 0, function() {
                    var t, n, i;
                    return R(this, function(e) {
                        return t = this.next,
                        n = function() {}
                        ,
                        i = new Promise(function(e) {
                            return n = e
                        }
                        ),
                        this.next = t.then(function() {
                            return i
                        }),
                        [2, t.then(function() {
                            return {
                                release: n
                            }
                        })]
                    })
                })
            }
            ;
            var se = ce;
            function ce() {
                this.next = Promise.resolve()
            }
            le.generateUUID = function() {
                for (var e = "", t = 0; t < 36; t++)
                    e += 8 === t || 13 === t || 18 === t || 23 === t ? "-" : 14 === t ? "4" : (19 === t ? Math.floor(4 * Math.random()) + 8 : Math.floor(16 * Math.random())).toString(16);
                return e
            }
            ;
            var ue = le;
            function le() {}
            de.prototype.getJsonForQueryString = function() {
                var e, t = {
                    fbc: this.fbcCookie.getValue(),
                    fbp: this.fbpCookie.getValue(),
                    crto_fbc: this.crtoFbcCookie.getValue(),
                    crto_fbp: this.crtoFbpCookie.getValue(),
                    ttclid: this.ttclidCookie.getValue(),
                    ttp: this.ttpCookie.getValue()
                }, n = {};
                for (e in t)
                    void 0 !== t[e] && (n[e] = t[e]);
                return 0 === Object.keys(n).length ? null : encodeURIComponent(JSON.stringify(n))
            }
            ;
            var pe = de;
            function de() {
                debugger;
                this.metaCookieRetentionTime = 7776e6,
                this.tiktokCookieRetentionTime = 34164e6,
                this.fbcCookie = new u("_fbc",this.metaCookieRetentionTime),
                this.fbpCookie = new u("_fbp",this.metaCookieRetentionTime),
                this.crtoFbcCookie = new u("crto_fbc",this.metaCookieRetentionTime),
                this.crtoFbpCookie = new u("crto_fbp",this.metaCookieRetentionTime),
                this.ttclidCookie = new u("ttclid",this.tiktokCookieRetentionTime),
                this.ttpCookie = new u("_ttp",this.tiktokCookieRetentionTime)
            }
            _.prototype.fillQueryStringParams = function(e, t) {
                var n = this.config.trackingCallData.firstPartyIdentifier
                  , i = this.config.trackingCallData.isStepAllowed("readSocialCookies") ? this.socialCookie.getJsonForQueryString() : "";
                n && e.push("fpid=" + n),
                this.gaid && e.push("ai=" + this.gaid),
                this.idfa && e.push("idfa=" + this.idfa),
                null !== this.clickOriginPayload && e.push("cop=" + this.clickOriginPayload),
                null !== this.optoutCookie.cookieValue && e.push("optout=1"),
                null != this.bundleCookie.cookieValue && (n = encodeURIComponent(this.bundleCookie.cookieValue),
                e.push("bundle=" + n)),
                null !== i && e.push("sc=" + i),
                null !== this.tld && e.push("tld=" + this.tld),
                t.privateModeDetectionEnabled && null !== this.privateMode && 0 !== this.privateMode ? e.push("pm=" + this.privateMode) : t.privateModeDetectionEnabled || e.push("pm=3"),
                void 0 !== new u("cto_clc",this.readonlyCookieRetentionTime).getValue() && e.push("clc=1")
            }
            ,
            _.prototype.checkAcid = function() {
                this.setCanWriteCookie(),
                this.setCanWriteLocalStorage()
            }
            ,
            _.prototype.setCop = function(e) {
                var t = S.getQueryString(e);
                if (void 0 !== t && (this.clickOriginPayload = this.getParameterValueByName(t, "cto_pld")),
                null === this.clickOriginPayload)
                    try {
                        var n = S.getAnchorWithReferrer(e.top.document);
                        n && n.search && (this.clickOriginPayload = this.getParameterValueByName(n.search, "cto_pld"))
                    } catch (e) {}
            }
            ,
            _.prototype.checkClientSideIdentityStatus = function() {
                this.optoutCookie.getFromAllStorages(),
                this.bundleCookie.setValueFromAllStorages(),
                this.ifaCookie.setValueFromAllStorages()
            }
            ,
            _.prototype.checkCookies = function(e) {
                var t = !0;
                if (e.callbacks) {
                    for (var n = 0, i = "string" == typeof e.callbacks ? [e.callbacks] : e.callbacks; n < i.length; n++) {
                        var o = i[n]
                          , r = document.createElement("img")
                          , o = (r.setAttribute("style", "display:none;"),
                        r.setAttribute("width", "1"),
                        r.setAttribute("height", "1"),
                        r.setAttribute("data-owner", "criteo-tag"),
                        r.setAttribute("src", o),
                        document.getElementsByTagName("script")[0]);
                        o.parentNode.insertBefore(r, o),
                        S.removeLater(this.exceptionHandler, r)
                    }
                    t = !1
                }
                e.optout ? (this.optoutCookie.setValue("1", t),
                this.bundleCookie.removeFromAllStorages()) : e.bundle && this.bundleCookie.setValue(e.bundle, t)
            }
            ,
            _.prototype.scrapIdentifiers = function(i) {
                return Object.keys(i.externalIdentifiersToRead).map(function(e) {
                    var t = i.externalIdentifiersToRead[e]
                      , n = new u(t.key,0,t.storageSource).getFromAllStorages().value
                      , t = n && t.transform ? t.transform(n) : n;
                    return null != t && 0 < t.length ? JSON.stringify({
                        type: e,
                        value: t
                    }) : ""
                }).filter(function(e) {
                    return 0 < e.length
                }).join(",")
            }
            ,
            _.prototype.getParameterValueByName = function(e, t) {
                if (e && 1 < e.length) {
                    var n, t = "&" + t + "=", i = (e = "?" === e[0] ? "&" + e.substr(1) : e).indexOf(t);
                    if (-1 !== i)
                        return n = e.indexOf("&", i + t.length),
                        e.slice(i + t.length, n < 0 ? void 0 : n)
                }
                return null
            }
            ,
            _.prototype.setCanWriteCookie = function() {
                this.canWriteCookie = u.checkCookiesAreWritable()
            }
            ,
            _.prototype.setCanWriteLocalStorage = function() {
                this.canWriteLocalStorage = u.checkLocalStorageIsWritable()
            }
            ,
            _.prototype.getTld = function() {
                var e = new u("cto_tld_test",36e5)
                  , t = e.setOnMainDomain("woot");
                return e.removeOnMainDomain(),
                t
            }
            ,
            _.prototype.getPrivateMode = function(e, t) {
                if (e.isSafari)
                    try {
                        if ("function" == typeof t.openDatabase)
                            return t.openDatabase(null, null, null, null),
                            1
                    } catch (e) {
                        return 2
                    }
                return 0
            }
            ;
            var he = _;
            function _(e, t, n, i) {
                this.readonlyCookieRetentionTime = 0,
                this.optoutCookieRetentionTime = 15768e7,
                this.identificationCookieRetentionTime = 34164e6,
                this.optoutCookie = new u("cto_optout",this.optoutCookieRetentionTime),
                this.bundleCookie = new u("cto_bundle",this.identificationCookieRetentionTime),
                this.ifaCookie = new u("id_controller_ifa",this.identificationCookieRetentionTime),
                this.socialCookie = new pe,
                this.canWriteCookie = !1,
                this.canWriteLocalStorage = !1,
                this.clickOriginPayload = null,
                this.tld = this.getTld(),
                this.privateMode = this.getPrivateMode(t, n),
                this.exceptionHandler = e,
                this.config = i
            }
            E.prototype.fillQueryStringParams = function(e, t) {}
            ,
            E.prototype.checkAcid = function() {}
            ,
            E.prototype.setCop = function(e) {}
            ,
            E.prototype.checkClientSideIdentityStatus = function() {}
            ,
            E.prototype.checkCookies = function(e) {}
            ,
            E.prototype.scrapIdentifiers = function(e) {
                return ""
            }
            ;
            var fe = E;
            function E() {
                this.optoutCookie = new u("empty",0),
                this.bundleCookie = new u("empty",0),
                this.ifaCookie = new u("empty",0),
                this.clickOriginPayload = null,
                this.tld = null,
                this.canWriteCookie = !1,
                this.canWriteLocalStorage = !1,
                this.privateMode = 0
            }
            ge.prototype.createIframe = function(e, t, n, i, o) {
                var r = document.createElement("iframe")
                  , a = encodeURIComponent || escape
                  , s = S.getHighestAccessibleUrl(window)
                  , a = a(S.extractHostname(s))
                  , s = window.SYNCFRAME_ORIGIN || "onetag"
                  , t = {
                    bundle: e.bundleCookie.toFragmentData(),
                    cw: e.canWriteCookie,
                    optout: e.optoutCookie.toFragmentData(),
                    origin: s,
                    tld: e.tld,
                    topUrl: a,
                    version: t.replace(/\./g, "_"),
                    ifa: e.ifaCookie.toFragmentData(),
                    lsw: e.canWriteLocalStorage,
                    pm: i ? e.privateMode : 3,
                    requestId: this.requestId
                }
                  , c = new URL(this.gumSyncFrameEndPoint);
                function u(e, t) {
                    null != t && c.searchParams.set(e, t)
                }
                "#gum-debug-mode" === window.location.hash && u("debug", "1"),
                u("topUrl", a),
                u("origin", s);
                i = o.gdprConsent,
                i && (u("gdpr", i.gdprApplies ? "1" : "0"),
                u("gdpr_consent", i.consentData)),
                u("us_privacy", null == (e = o.ccpaConsent) ? void 0 : e.uspString),
                a = o.gppConsent;
                return a && (u("gpp", a.gpp),
                u("gpp_sid", null == (s = a.gppSid) ? void 0 : s.join(","))),
                c.hash = JSON.stringify(t),
                r.src = c.toString(),
                r.id = this.gumSyncFrameId,
                d("styleIframes", !(r.hidden = !0)) && (r.style.display = "none"),
                r.setAttribute("sandbox", "allow-scripts allow-same-origin"),
                r.setAttribute("aria-hidden", "true"),
                r.setAttribute("tabindex", "-1"),
                r.title = "Criteo GUM iframe",
                S.removeLater(n, r),
                r
            }
            ,
            ge.prototype.setWaitingFlag = function(e) {
                this.waitingForSyncframe = this.waitingForSyncframe && null === e.bundleCookie.cookieValue && null === e.optoutCookie.cookieValue
            }
            ,
            ge.prototype.shouldInjectSyncframe = function() {
                return (void 0 !== window.addEventListener || this.forceSyncFrame) && this.enableOffsiteProjection
            }
            ;
            var me = ge;
            function ge() {
                this.forceSyncFrame = !1,
                this.gumSyncFrameOrigin = "https://" + d("gumDomain", "gum.criteo.com"),
                this.gumSyncFrameEndPoint = W("CriteoSyncFrameUrlOverride", this.gumSyncFrameOrigin + "/syncframe"),
                this.gumSyncFrameId = "criteo-syncframe-onetag",
                this.enableOffsiteProjection = d("enableOffsiteProjection", !0),
                this.waitingForSyncframe = this.enableOffsiteProjection,
                this.requestId = ue.generateUUID()
            }
            ye.prototype.createIframe = function(e, t, n, i, o) {
                return document.createElement("iframe")
            }
            ,
            ye.prototype.setWaitingFlag = function(e) {}
            ,
            ye.prototype.shouldInjectSyncframe = function() {
                return !1
            }
            ;
            var ve = ye;
            function ye() {
                this.gumSyncFrameOrigin = "",
                this.gumSyncFrameEndPoint = "",
                this.gumSyncFrameId = "",
                this.forceSyncFrame = !1,
                this.waitingForSyncframe = !1,
                this.enableOffsiteProjection = !1,
                this.requestId = null
            }
            var Ce = new RegExp(/^Mozilla\/5\.0 \([^)]+\) AppleWebKit\/[^ ]+ \(KHTML, like Gecko\) Version\/([^ ]+)( Mobile\/[^ ]+)? Safari\/[^ ]+$/i)
              , we = (A.prototype.canRetrieveMetrics = function() {
                return this.hasPerformanceApi
            }
            ,
            A.prototype.startRecordingInit = function() {
                this.canRetrieveMetrics() && (this.beginInit = performance.now())
            }
            ,
            A.prototype.stopRecordingInit = function() {
                var e;
                this.canRetrieveMetrics() && null === this.timings.initTime && null !== this.beginInit && (e = performance.now(),
                this.timings.initTime = e - this.beginInit)
            }
            ,
            A.prototype.startRecordingPush = function() {
                this.canRetrieveMetrics() && (this.beginPush = performance.now())
            }
            ,
            A.prototype.stopRecordingPush = function() {
                var e;
                this.canRetrieveMetrics() && null === this.timings.pushTime && null !== this.beginPush && null !== this.timings.initTime && (e = performance.now(),
                this.timings.pushTime = e - this.beginPush)
            }
            ,
            A.prototype.getPerformanceOrDegradedNow = function() {
                return this.canRetrieveMetrics() ? performance.now() : (new Date).getTime()
            }
            ,
            A);
            function A() {
                this.timings = {
                    initTime: null,
                    pushTime: null
                },
                this.beginInit = null,
                this.beginPush = null,
                this.hasPerformanceApi = void 0 !== window.performance && "function" == typeof window.performance.now
            }
            x.prototype.init = function() {
                var t = this;
                d("smartPiiCollectionEnabled", !1) && (this.exceptionHandler.addProtectedEventListener(this.document, "click", function(e) {
                    e = e.target;
                    e instanceof HTMLButtonElement && e.form && t.handleForm(e.form)
                }, !0),
                this.exceptionHandler.addProtectedEventListener(this.document, "submit", function(e) {
                    e = e.target;
                    e instanceof HTMLFormElement && t.handleForm(e)
                }, !0))
            }
            ,
            x.prototype.handleForm = function(o) {
                return l(this, void 0, void 0, function() {
                    var t, n, i;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return this.registerAndCheckFormProcessing(o) ? 0 < (t = this.scanFormInputs(o)).length ? (n = this.trackingCallData.requestType,
                            i = this.trackingCallData.responseType,
                            [4, this.criteoQ.pushInternal(c([{
                                event: "setRequestType",
                                type: "beacon"
                            }], t))]) : [3, 3] : [2];
                        case 1:
                            return e.sent(),
                            [4, this.criteoQ.pushInternal([{
                                event: "setRequestType",
                                type: n
                            }, {
                                event: "setResponseType",
                                type: i
                            }])];
                        case 2:
                            e.sent(),
                            e.label = 3;
                        case 3:
                            return [2]
                        }
                    })
                })
            }
            ,
            x.prototype.registerAndCheckFormProcessing = function(e) {
                var t = this;
                return !this.processingForms.has(e) && (this.processingForms.add(e),
                this.exceptionHandler.setProtectedTimeout(function() {
                    return t.processingForms.delete(e)
                }, 100),
                !0)
            }
            ,
            x.prototype.scanFormInputs = function(e) {
                var a = []
                  , e = e.querySelectorAll('input:not([type="password"])')
                  , s = c(x.MATCHING_CONF);
                return e.forEach(function(e) {
                    var t = null == (n = e.value) ? void 0 : n.trim();
                    if (t && !(t.length < 6)) {
                        var n = d("smartPiiCollectionBlocklist", [])
                          , i = c(Array.from(e.classList), [e.id, e.name])
                          , e = n.some(function(t) {
                            return i.some(function(e) {
                                return e.toLowerCase().includes(t.toLowerCase())
                            })
                        });
                        if (!e)
                            for (var o = 0; o < s.length; o++) {
                                var r = s[o];
                                if (r.regex.test(t)) {
                                    a.push(r.action(t)),
                                    s.splice(o, 1),
                                    o--;
                                    break
                                }
                            }
                    }
                }),
                a
            }
            ,
            x.MATCHING_CONF = [{
                regex: x.EMAIL_REGEX = /^\w[\w.-]*@\w[\w.-]*\.\w+$/,
                action: function(e) {
                    return {
                        event: "setEmail",
                        email: e.toLowerCase()
                    }
                }
            }, {
                regex: x.PHONE_REGEX = /^(\+|00)[\s\-().]*(\d[\s\-().]*){7,15}$/,
                action: function(e) {
                    return {
                        event: "setPhoneNumber",
                        phone_number: e.replace(/[^\d+]/g, "")
                    }
                }
            }];
            var be = x;
            function x(e, t, n, i) {
                this.processingForms = new Set,
                this.document = e,
                this.criteoQ = t,
                this.trackingCallData = n,
                this.exceptionHandler = i
            }
            M.prototype.trySetPageId = function(e, t) {
                this.shouldFillPageId && this.isCbsEnabled && this.checkNotExistOrEmpty(e.page_id) && (e.page_id = t)
            }
            ,
            M.prototype.tryForceViewListPageId = function(e) {
                this.shouldFillPageId && this.isCbsEnabled && this.checkNotExistOrEmpty(e.page_id) && (this.checkNotExistOrEmpty(e.category) ? this.checkNotExistOrEmpty(e.keywords) ? e.page_id = "viewList" : e.page_id = "viewSearchResult" : e.page_id = "viewCategory")
            }
            ,
            M.prototype.tryAdBlockDetection = function(r) {
                return l(this, void 0, void 0, function() {
                    var n, i, o = this;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return null == (i = window.criteo_q) ? [2] : (n = i.adBlockDetector,
                            this.isCbsEnabled && void 0 !== n ? (i = new Promise(function(t) {
                                n(function(e) {
                                    o.abe = e,
                                    t()
                                })
                            }
                            ),
                            [4, Promise.race([i, (t = r,
                            new Promise(function(e) {
                                return setTimeout(e, t)
                            }
                            ))])]) : [2]);
                        case 1:
                            return e.sent(),
                            [2]
                        }
                        var t
                    })
                })
            }
            ,
            M.prototype.tryAppendAdBlockerParameter = function(e) {
                void 0 !== this.abe && e.push("abe=" + (this.abe ? 1 : 0))
            }
            ,
            M.prototype.tryAppendUatParameter = function(e) {
                var t;
                this.isCbsEnabled && void 0 !== this.uat && (t = encodeURIComponent || escape,
                e.push("uat=" + t(this.uat)))
            }
            ,
            M.prototype.clean = function() {
                this.abe = void 0,
                this.isCbsEnabled = !1,
                this.uat = void 0
            }
            ,
            M.prototype.enable = function() {
                this.isCbsEnabled = !0
            }
            ,
            M.prototype.setUat = function(e) {
                this.uat = e
            }
            ,
            M.prototype.checkNotExistOrEmpty = function(e) {
                return void 0 === e || "" === e
            }
            ;
            var ke = M;
            function M() {
                this.abe = void 0,
                this.isCbsEnabled = !1,
                this.uat = void 0,
                this.shouldFillPageId = d("shouldFillPageId", !0)
            }
            Object.defineProperty(Se.prototype, "accounts", {
                get: function() {
                    return this.observableAccounts.get()
                },
                enumerable: !1,
                configurable: !0
            }),
            Se.prototype.onAccountsChange = function(e) {
                this.observableAccounts.onPropertyChange(e)
            }
            ;
            var Pe = Se;
            function Se() {
                this.actions = [],
                this.bodyReady = !1,
                this.disingScheduled = [],
                this.domReady = !1,
                this.eventSent = !1,
                this.queue = [],
                this.observableAccounts = new N([])
            }
            var Ie = /^#(enable|disable)-criteo-tag-debug-mode(=(\d+))?$/;
            function De(e, t, n, i, o) {
                var r, a, s, c;
                return document && window.location.hash && (a = Ie.exec(window.location.hash)) && 4 === a.length && (r = "enable" === a[1],
                a = Number(a[3]),
                new u("criteoTagDebugMode",r ? 864e5 : 0).setValueWithNoDomain(r && a && !isNaN(a) ? String(a) : "0"),
                window.location.href = window.location.href.substr(0, window.location.href.indexOf("#"))),
                document && "function" == typeof Array.prototype.indexOf && -1 !== document.cookie.indexOf("criteoTagDebugMode=") ? (s = o,
                c = {
                    exceptions: e.exceptions,
                    m_config: n,
                    m_state: i,
                    originalPush: e.push,
                    performances: e.performances,
                    push: function() {
                        for (var e = [], t = 0; t < arguments.length; t++)
                            e[t] = arguments[t];
                        this.pushInternal(e)
                    },
                    pushInternal: function() {
                        for (var e = [], t = 0; t < arguments.length; t++)
                            e[t] = arguments[t];
                        return 0 < e.length && this.stagedPushes.push(e),
                        s.stopRecordingInit(),
                        Promise.resolve()
                    },
                    pushError: function(e) {
                        this.stagedPushes.push(e)
                    },
                    removeLater: e.removeLater,
                    setProtectedTimeout: t.setProtectedTimeout,
                    stagedErrors: [],
                    stagedPushes: []
                },
                window.onerror = function(o) {
                    return function(e, t, n, i) {
                        return c.pushError({
                            column: i,
                            lineNumber: n,
                            message: e,
                            url: t
                        }),
                        !(!o || "function" != typeof o) && o.apply(window, [e, t, n, i])
                    }
                }(window.onerror),
                r = c,
                document && (a = "ld-tag-debug." + V + ".js",
                (o = document.createElement("script")).setAttribute("type", "text/javascript"),
                o.setAttribute("src", document.location.protocol + "//static.criteo.net/js/ld/" + a),
                (a = document.getElementsByTagName("script")[0]).parentNode.insertBefore(o, a)),
                r) : e
            }
            function Te(o, r, a) {
                function e(i) {
                    return void 0 === i && (i = !1),
                    l(t, void 0, void 0, function() {
                        var t, n;
                        return R(this, function(e) {
                            switch (e.label) {
                            case 0:
                                return r.eventSent ? [3, 4] : i ? [4, o.pushInternal({
                                    event: "setRequestType",
                                    type: "beacon"
                                })] : [3, 2];
                            case 1:
                                e.sent(),
                                e.label = 2;
                            case 2:
                                return t = {
                                    event: "viewPage"
                                },
                                n = d("guessedPartnerIds"),
                                a.account || void 0 === n || (t.account = n),
                                [4, o.pushInternal(t)];
                            case 3:
                                e.sent(),
                                e.label = 4;
                            case 4:
                                return [2]
                            }
                        })
                    })
                }
                var t = this
                  , n = (window.addEventListener && window.addEventListener("pagehide", function() {
                    return e(!0)
                }),
                d("visitEventDelay", 5e3));
                0 <= n && setTimeout(e, n)
            }
            L.prototype.push = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                this.pushInternal.apply(this, e)
            }
            ,
            L.prototype.pushInternal = function() {
                for (var r = [], e = 0; e < arguments.length; e++)
                    r[e] = arguments[e];
                return l(this, void 0, void 0, function() {
                    var t = this;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this.exceptionHandler.catchAndStoreException(function() {
                                return l(t, void 0, void 0, function() {
                                    var t, n, i, o;
                                    return R(this, function(e) {
                                        switch (e.label) {
                                        case 0:
                                            return [4, this.pushLock.acquire()];
                                        case 1:
                                            t = e.sent(),
                                            e.label = 2;
                                        case 2:
                                            for (e.trys.push([2, , 4, 5]),
                                            this.performanceMetrics.startRecordingPush(),
                                            n = 0,
                                            i = r; n < i.length; n++)
                                                o = i[n],
                                                this.mState.app.queue.push(o);
                                            return [4, this.evalQueue()];
                                        case 3:
                                            return e.sent(),
                                            this.cleanConfigurationAndState(),
                                            this.performanceMetrics.stopRecordingPush(),
                                            [3, 5];
                                        case 4:
                                            return t.release(),
                                            [7];
                                        case 5:
                                            return [2]
                                        }
                                    })
                                })
                            }, r)];
                        case 1:
                            return e.sent(),
                            this.performanceMetrics.stopRecordingInit(),
                            [2]
                        }
                    })
                })
            }
            ,
            L.prototype.removeLater = function(e) {
                S.removeLater(this.exceptionHandler, e)
            }
            ,
            L.prototype.setupSyncFrameWait = function() {
                var e = this;
                this.mSyncframe.setWaitingFlag(this.mIdentification),
                this.mSyncframe.waitingForSyncframe && this.exceptionHandler.setProtectedTimeout(function() {
                    return l(e, void 0, void 0, function() {
                        return R(this, function(e) {
                            switch (e.label) {
                            case 0:
                                return [4, this.unblockEvents()];
                            case 1:
                                return e.sent(),
                                [2]
                            }
                        })
                    })
                }, 1e4)
            }
            ,
            L.prototype.unblockEvents = function() {
                return l(this, void 0, void 0, function() {
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return this.mSyncframe.waitingForSyncframe ? (this.mSyncframe.waitingForSyncframe = !1,
                            [4, this.evalQueue()]) : [3, 2];
                        case 1:
                            e.sent(),
                            e.label = 2;
                        case 2:
                            return [2]
                        }
                    })
                })
            }
            ,
            L.prototype.evalQueue = function() {
                return l(this, void 0, void 0, function() {
                    var t, n, i, o, r, a, s;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return [4, this.evalQueueLock.acquire()];
                        case 1:
                            t = e.sent(),
                            e.label = 2;
                        case 2:
                            e.trys.push([2, , 10, 11]),
                            n = this.mState.app,
                            i = [],
                            o = n.queue,
                            r = 0,
                            e.label = 3;
                        case 3:
                            return r < o.length ? ((a = o[r])instanceof Array && (s = [r + 1, 0],
                            o.splice.apply(o, s.concat(a))),
                            a instanceof Function ? (o.splice(r + 1, 0, a()),
                            [3, 6]) : [3, 4]) : [3, 7];
                        case 4:
                            return a && "[object Object]" === a.toString() ? [4, this.evalEvent(a, r, o, i)] : [3, 6];
                        case 5:
                            switch (e.sent()) {
                            case 0:
                                i.push(a);
                                break;
                            case -1:
                                i = i.concat(o.slice(r)),
                                r = o.length
                            }
                            e.label = 6;
                        case 6:
                            return ++r,
                            [3, 3];
                        case 7:
                            return this.mConfig.hooks.afterEval instanceof Function && this.mConfig.hooks.afterEval(),
                            n.queue = i || [],
                            this.mConfig.workflow.manualFlush || this.mConfig.workflow.noPartialFlush && 0 !== n.queue.length || this.mSyncframe.waitingForSyncframe ? [3, 9] : [4, this.flush(0 !== n.queue.length)];
                        case 8:
                            e.sent(),
                            e.label = 9;
                        case 9:
                            return [3, 11];
                        case 10:
                            return t.release(),
                            [7];
                        case 11:
                            return [2]
                        }
                    })
                })
            }
            ,
            L.prototype.evalEvent = function(f, m, g, v) {
                return l(this, void 0, void 0, function() {
                    var t, n, i, o, r, a, s, c, u, l, p, d, h;
                    return R(this, function(e) {
                        if (t = this.mState.app,
                        n = this.mState.cbs,
                        i = this.mIdentification,
                        o = this.mConfig.trackingCallData,
                        r = this.mConfig.hooks,
                        a = this.mConfig.workflow,
                        s = f.event,
                        null !== (c = this.beforeEvalEvent(f)))
                            return [2, c];
                        switch (f.event) {
                        case "setdata":
                            return [2, T(o.extraData, t.actions, f)];
                        case "setparameter":
                            for (u in f)
                                "event" !== u.toLowerCase() && f.hasOwnProperty(u) && (o.handlerParams[u] = f[u]);
                            return [2, 1];
                        case "calldising":
                            this.innerEvalCallDisingEvent(f);
                            break;
                        case "setzipcode":
                        case "setstore":
                            return f.event = "setdata",
                            [2, T(o.extraData, t.actions, f)];
                        case "setcustomerid":
                            return f.event = "setdata",
                            f.customer_id = f.id,
                            delete f.id,
                            [2, T(o.extraData, t.actions, f)];
                        case "setretailervisitorid":
                            return n.enable(),
                            f.event = "setdata",
                            void 0 !== f.id && null !== f.id && (f.retailer_visitor_id = f.id),
                            delete f.id,
                            [2, T(o.extraData, t.actions, f)];
                        case "setgoogleadvertisingid":
                            return i.gaid = f.gaid,
                            [2, T(o.extraData, t.actions, {
                                event: "setdata",
                                site_type: "aa"
                            })];
                        case "setappleadvertisingid":
                            return i.idfa = f.idfa,
                            [2, T(o.extraData, t.actions, {
                                event: "setdata",
                                site_type: "aios"
                            })];
                        case "setemail":
                        case "sethashedemail":
                        case "ceh":
                            return f.event = "setemail",
                            f.hasOwnProperty("email") && (f.email instanceof Array || (f.email = [f.email]),
                            f.email = ie(f.email)),
                            l = D(f),
                            o.customerInfo.push(l),
                            re(t.actions, D(f)),
                            [2, 1];
                        case "setphonenumber":
                        case "setsha256hashedphonenumber":
                            return f.hasOwnProperty("phone_number") && 0 < (l = ie(l = f.phone_number instanceof Array ? f.phone_number : [f.phone_number])).length ? (p = "setphonenumber" == f.event ? "pnclear" : "pnsha256",
                            d = {
                                source: "onetag",
                                uids: l.map(function(e) {
                                    return {
                                        id: e,
                                        atype: 3,
                                        ext: {
                                            stype: p
                                        }
                                    }
                                })
                            },
                            delete f.phone_number,
                            f.event = "setIdentity",
                            f.identity = [d],
                            t.actions.push(D(f)),
                            [2, 1]) : [2, 0];
                        case "setidentity":
                            return f.hasOwnProperty("identity") && 0 < (d = ie(f.identity instanceof Array ? f.identity : [f.identity])).length ? (f.identity = d,
                            t.actions.push(D(f)),
                            [2, 1]) : [2, 0];
                        case "setsitetype":
                            return h = "d",
                            "aios" !== f.type && "aa" != f.type || (h = f.type),
                            "mobile" !== f.type && "m" !== f.type || (h = "m"),
                            "tablet" !== f.type && "t" !== f.type || (h = "t"),
                            f.event = "setdata",
                            delete f.type,
                            f.site_type = h,
                            [2, T(o.extraData, t.actions, f)];
                        case "appendtag":
                            return [2, this.innerEvalAppendTagEvent(f)];
                        case "gettagstate":
                            return f.callback instanceof Function ? [2, f.callback(this.mState, this.mConfig, this.mIdentification, this.mSyncframe)] : [2, 1];
                        case "setuat":
                            return this.mState.cbs.setUat(f.uat),
                            [2, 1];
                        case "viewsearchresult":
                        case "viewcategory":
                            n.trySetPageId(f, s),
                            f.event = "viewlist";
                            break;
                        case "viewlist":
                            n.tryForceViewListPageId(f);
                            break;
                        case "viewitem":
                        case "viewhome":
                        case "viewbasket":
                        case "tracktransaction":
                        case "addtocart":
                            n.trySetPageId(f, s);
                            break;
                        case "viewstore":
                            n.trySetPageId(f, s),
                            f.event = "viewHome",
                            f.sub_event_type = "s";
                            break;
                        case "checkavailability":
                            n.trySetPageId(f, s),
                            f.event = "viewBasket",
                            f.sub_event_type = "a";
                            break;
                        case "reserveinstore":
                            n.trySetPageId(f, s),
                            f.event = "viewBasket",
                            f.sub_event_type = "r";
                            break;
                        case "flush":
                        case "flushevents":
                            return this.flush(m !== g.length - 1 || 0 !== v.length),
                            [2, 1];
                        case "setaccount":
                            return o.account = f.account,
                            [2, 1];
                        case "seturl":
                            return o.handlerUrlPrefix = f.url,
                            [2, 1];
                        case "setcalltype":
                            return o.handlerResponseType = f.type,
                            [2, 1];
                        case "setresponsetype":
                            return o.responseType = f.type,
                            [2, 1];
                        case "setrequesttype":
                            return o.requestType = f.type,
                            [2, 1];
                        case "setpartnerpayload":
                            return o.partnerPayload = f.payload,
                            [2, 1];
                        case "oninitialized":
                            return r.onInitialized = f.callback,
                            [2, 1];
                        case "ondomready":
                            return r.onDOMReady = f.callback,
                            [2, 1];
                        case "beforeappend":
                            return r.beforeAppend = f.callback,
                            [2, 1];
                        case "aftereval":
                            return r.afterEval = f.callback,
                            [2, 1];
                        case "onflush":
                            return r.onFlush = f.callback,
                            [2, 1];
                        case "onurlgenerated":
                            return r.onUrlGenerated = f.callback,
                            [2, 1];
                        case "disonce":
                            return a.disOnce = !0,
                            [2, 1];
                        case "manualdising":
                            return a.manualDising = !0,
                            [2, 1];
                        case "manualflush":
                            return a.manualFlush = !0,
                            [2, 1];
                        case "nopartialflush":
                            return a.noPartialFlush = !0,
                            [2, 1];
                        case "disonpartialflush":
                            return a.partialDis = !0,
                            [2, 1]
                        }
                        return t.actions.push(D(f)),
                        [2, 1]
                    })
                })
            }
            ,
            L.prototype.flush = function(T) {
                return l(this, void 0, void 0, function() {
                    var a, s, c, u, l, p, d, h, f, m, g, v, y, C, w, b, k, P, S, I, D;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            if (a = this.mState.app,
                            s = this.mState.cbs,
                            c = this.mConfig.trackingCallData,
                            u = this.mConfig.workflow,
                            (l = this.mConfig.hooks).onFlush instanceof Function && (l.onFlush(),
                            F.warn("on flush hook is deprecated and will soon be removed. Please do not use it and contact criteo if you think this may break your integration")),
                            0 === a.actions.length)
                                return [2];
                            for (p = 0,
                            d = c.extraData; p < d.length; p++)
                                h = d[p],
                                oe(a.actions, h);
                            for (f = 0,
                            m = c.customerInfo; f < m.length; f++)
                                g = m[f],
                                re(a.actions, g);
                            for (v = 0,
                            y = a.actions; v < y.length; v++)
                                C = y[v],
                                (r = void 0) !== (o = C).identity && JSON.stringify && (r = o.identity instanceof Array ? o.identity : [o.identity],
                                o.raw_identity = JSON.stringify(r),
                                delete o.identity);
                            if (!u.manualDising && (!T || u.partialDis)) {
                                for (w = [],
                                b = 0,
                                k = a.accounts; b < k.length; b++)
                                    P = k[b],
                                    ne(a.disingScheduled, P) || w.push(P);
                                0 < w.length && this.evalCallDisingEvent({
                                    event: "callDising",
                                    account: w
                                })
                            }
                            return S = this.getQueryParams(),
                            a.actions = [],
                            [4, this.mConsentManager.retrieveConsent()];
                        case 1:
                            return I = e.sent(),
                            S.push.apply(S, (t = I,
                            n = new URLSearchParams,
                            (i = t.gdprConsent) && (void 0 !== i.gdprApplies && n.set("gra", i.gdprApplies ? "1" : "0"),
                            void 0 !== i.consentData && n.set("grs", i.consentData),
                            void 0 !== i.version) && n.set("grv", i.version.toString()),
                            (i = t.ccpaConsent) && (void 0 !== i.uspString && n.set("cs", i.uspString),
                            void 0 !== i.version) && n.set("cv", i.version.toString()),
                            (i = t.gppConsent) && (void 0 !== i.gpp && n.set("gpp", i.gpp),
                            void 0 !== i.gppSid) && i.gppSid.forEach(function(e) {
                                n.append("gpp_sid", e.toString())
                            }),
                            (t = n.toString()) ? t.split("&") : [])),
                            [4, s.tryAdBlockDetection(500)];
                        case 2:
                            if (e.sent(),
                            !(c.isStepAllowed("readCmaTestLabel") && "cookieDeprecationLabel"in navigator))
                                return [3, 6];
                            e.label = 3;
                        case 3:
                            return e.trys.push([3, 5, , 6]),
                            [4, navigator.cookieDeprecationLabel.getValue()];
                        case 4:
                            return I = e.sent(),
                            S.push("cl=" + I),
                            [3, 6];
                        case 5:
                            return e.sent(),
                            [3, 6];
                        case 6:
                            return s.tryAppendAdBlockerParameter(S),
                            D = this.generateQueryString(S),
                            D = this.buildHandlerCall(D),
                            "function" == typeof l.onUrlGenerated ? l.onUrlGenerated(D.url) : "beacon" === c.requestType && navigator.sendBeacon ? navigator.sendBeacon(D.url) : this.evalAppendTagEvent(D),
                            F.info("DIS call triggered", D.url, S),
                            a.eventSent = !0,
                            u.disOnce || (a.disingScheduled = []),
                            [2]
                        }
                        var t, n, i, o, r
                    })
                })
            }
            ,
            L.prototype.beforeEvalEvent = function(e) {
                var t = this;
                return !this.mState.app.domReady && e.requiresDOM && "no" !== e.requiresDOM ? "blocking" === e.requiresDOM ? -1 : 0 : (delete e.requiresDOM,
                e.event ? (e.account && te(e.account, this.mState.app.accounts, function(e) {
                    return t.parseAccount(e) || e
                }),
                e.event = e.event.toLowerCase(),
                null) : (D(e),
                1))
            }
            ,
            L.prototype.parseAccount = function(e) {
                if ("number" == typeof e)
                    return e;
                if ("string" == typeof e) {
                    e = parseInt(e, 10);
                    if (!isNaN(e))
                        return e
                }
            }
            ,
            L.prototype.innerEvalCallDisingEvent = function(e) {
                e.hasOwnProperty("account") || (e.account = this.mState.app.accounts);
                var t = this.mConfig.trackingCallData.handlerResponseType;
                e.hasOwnProperty("type") && (t = e.type,
                delete e.type),
                te(e.account, this.mState.app.disingScheduled),
                "sequential" === t && (e.dc = !0)
            }
            ,
            L.prototype.innerEvalAppendTagEvent = function(e) {
                var t = this.mConfig.workflow;
                if (!this.mState.app.bodyReady || t.container && document.body.contains(t.container) || (t.container = S.appendCriteoContainer(document.body)),
                e.url && (n = void 0,
                e.isImgUrl ? ((n = document.createElement("img")).setAttribute("style", "display:none;"),
                n.setAttribute("width", "1"),
                n.setAttribute("height", "1")) : ((n = document.createElement("script")).setAttribute("async", "true"),
                n.setAttribute("type", "text/javascript")),
                n.setAttribute("src", e.url),
                e.element = n),
                this.mConfig.hooks.beforeAppend instanceof Function && (e.element = this.mConfig.hooks.beforeAppend(e.element)),
                D(e),
                e.element && (e.element.tagName || e.isImgUrl)) {
                    if (t.container || "script" !== e.element.tagName.toLowerCase() && !e.isImgUrl) {
                        if (!t.container)
                            return 0;
                        t.container.appendChild(e.element)
                    } else {
                        var n = document.getElementsByTagName("script")[0];
                        e.element.setAttribute("data-owner", "criteo-tag"),
                        n.parentNode.insertBefore(e.element, n)
                    }
                    S.removeLater(this.exceptionHandler, e.element)
                }
                return 1
            }
            ,
            L.prototype.evalCallDisingEvent = function(e) {
                var t = this.beforeEvalEvent(e);
                return null !== t ? t : (this.innerEvalCallDisingEvent(e),
                this.mState.app.actions.push(D(e)),
                1)
            }
            ,
            L.prototype.getQueryParams = function() {
                var e = this.mState.app
                  , t = this.mConfig.trackingCallData
                  , n = e.actions
                  , i = []
                  , e = (1 === e.accounts.length && (t.account = e.accounts[0]),
                null !== t.account && i.push("a=" + this.toQuery(t.account, [])),
                "beacon" === t.requestType && navigator.sendBeacon && (t.responseType = "gif"),
                "js" !== t.responseType && i.push("rt=" + this.toQuery(t.responseType, [])),
                t.handlerParams && (e = decodeURIComponent(this.toQuery(t.handlerParams, []))) && i.push(e),
                this.getNonceValueFromDOM());
                void 0 !== e && (a = encodeURIComponent || escape,
                i.push("csp-nonce=" + a(e))),
                this.mState.cbs.tryAppendUatParameter(i);
                for (var o = 0; o < n.length; ++o) {
                    var r = n[o];
                    r.account && P(null === t.account ? void 0 : t.account, r.account) && delete r.account,
                    i.push("p" + o + "=" + this.toQuery(r, []))
                }
                this.mIdentification.fillQueryStringParams(i, t),
                null !== t.partnerPayload && i.push("pp=" + this.toQuery(t.partnerPayload, []));
                t.dynamic && i.push("dy=1");
                var a = S.getHighestAccessibleUrl(window)
                  , a = (Fe(this.maybeRemoveQueryParams(a, t), i, t.fullUrlMaxLength, "fu", "ful"),
                t.isStepAllowed("readPreviousUrl") && (e = S.getPreviousUrl(window),
                Fe(e = this.maybeRemoveQueryParams(e, t), i, t.previousUrlMaxLength, "pu", "pul")),
                ue.generateUUID())
                  , e = (this.cspLogger.setClientRequestId(a),
                i.push("ceid=" + a),
                this.mIdentification.scrapIdentifiers(this.mConfig.identifierScrappingConfig));
                return 0 < e.length && i.push("external_advids=" + encodeURIComponent("[" + e + "]")),
                i
            }
            ,
            L.prototype.maybeRemoveQueryParams = function(t, e) {
                if (0 === e.excludedReferrerParams.length)
                    return t;
                var i;
                try {
                    i = new URL(t)
                } catch (e) {
                    return t
                }
                return e.excludedReferrerParams.forEach(function(n) {
                    i.searchParams.forEach(function(e, t) {
                        (t.includes(n) || e.includes(n)) && i.searchParams.delete(t)
                    }),
                    i.hash.includes(n) && (i.hash = "")
                }),
                i.toString()
            }
            ,
            L.prototype.toQuery = function(e, t) {
                var n = encodeURIComponent || escape
                  , i = "";
                if (e instanceof Function)
                    i = this.toQuery(e(), t);
                else if (e instanceof Array) {
                    for (var o = [], r = 0; r < e.length; ++r)
                        o[r] = this.toQuery(e[r], t);
                    i += "[" + o.join(",") + "]"
                } else if (e && "[object Object]" === e.toString()) {
                    var a, s, c = [];
                    for (a in e)
                        e.hasOwnProperty(a) && (s = t.concat([a]),
                        c.push(this.applyPropMap(a, s) + "=" + this.toQuery(e[a], s)));
                    i += c.join("&")
                } else if (1 === t.length && "event" === t[0])
                    i += this.mConfig.shortNameMap.events[e.toLowerCase()] ? this.mConfig.shortNameMap.events[e.toLowerCase()] : e;
                else {
                    var u = this.parseArrayFromString(t, e);
                    if (0 < u.length)
                        return this.toQuery(u, t);
                    this.shouldEncodeField(t) ? i += n(e) : i += e
                }
                return n(i)
            }
            ,
            L.prototype.applyPropMap = function(e, t) {
                t = t.join(".");
                return this.mConfig.shortNameMap.properties[t] || e
            }
            ,
            L.prototype.parseArrayFromString = function(e, t) {
                e = e.join(".");
                return "string" == typeof t && this.mConfig.parsingConfig.shouldParseField(e) && 0 != t.length && "[" == t.charAt(0) && "]" == t.charAt(t.length - 1) ? t.substring(1, t.length - 1).split(",", -1).map(function(e) {
                    return e.trim()
                }) : []
            }
            ,
            L.prototype.shouldEncodeField = function(e) {
                e = e.join(".");
                return this.mConfig.encodingConfig.shouldEncodeField(e)
            }
            ,
            L.prototype.getNonceValueFromDOM = function() {
                for (var e = document.getElementsByTagName("script"), t = 0; t < e.length; t++) {
                    var n = e[t]
                      , n = n.nonce || n.getAttribute("nonce");
                    if (null != n && "" !== n)
                        return n
                }
            }
            ,
            L.prototype.generateQueryString = function(e) {
                return e.join("&")
            }
            ,
            L.prototype.buildHandlerCall = function(e) {
                return {
                    event: "appendTag",
                    isImgUrl: "gif" === this.mConfig.trackingCallData.responseType,
                    url: this.mConfig.trackingCallData.handlerUrlPrefix + "?" + e
                }
            }
            ,
            L.prototype.evalAppendTagEvent = function(e) {
                var t = this.beforeEvalEvent(e);
                return null !== t ? t : this.innerEvalAppendTagEvent(e)
            }
            ,
            L.prototype.tryWriteCriteoCookiesOnAdvertiserDomain = function(e) {
                var t = this;
                this.mSyncframe.shouldInjectSyncframe() && (e = this.mSyncframe.createIframe(this.mIdentification, this.mConfig.trackingCallData.tagVersion, this.exceptionHandler, this.mConfig.trackingCallData.privateModeDetectionEnabled, e),
                window.addEventListener) && (this.exceptionHandler.addProtectedEventListener(window, "message", function(e) {
                    return t.onMessageReceived(e)
                }, !0),
                this.evalAppendTagEvent({
                    event: "appendtag",
                    element: e
                }))
            }
            ,
            L.prototype.onMessageReceived = function(r) {
                return l(this, void 0, void 0, function() {
                    var t, n, i, o;
                    return R(this, function(e) {
                        switch (e.label) {
                        case 0:
                            return (t = r.data,
                            n = !W("BypassSyncframeMessageSanityCheck", !1),
                            i = t && r.origin === this.mSyncframe.gumSyncFrameOrigin,
                            o = t && t.requestId === this.mSyncframe.requestId,
                            !n || i || o) ? (r.stopPropagation(),
                            this.mIdentification.checkCookies(t),
                            this.mSyncframe.waitingForSyncframe ? [4, this.unblockEvents()] : [3, 2]) : [2];
                        case 1:
                            e.sent(),
                            e.label = 2;
                        case 2:
                            return [2]
                        }
                    })
                })
            }
            ,
            L.prototype.cleanConfigurationAndState = function() {
                var e = this.mConfig.trackingCallData.extraData
                  , t = !1;
                if (200 < e.length)
                    t = !0;
                else
                    for (var n = 0, i = e; n < i.length; n++) {
                        var o = i[n]
                          , r = 0;
                        if (Object.keys)
                            r = Object.keys(o).length;
                        else
                            for (var a in o)
                                Object.prototype.hasOwnProperty.call(o, a) && (r += 1);
                        if (200 < r) {
                            t = !0;
                            break
                        }
                    }
                t && (e.length = 0),
                this.mConfig.trackingCallData.customerInfo = [],
                this.mState.cbs.clean()
            }
            ,
            L.prototype.setupCspLogger = function() {
                function t(e) {
                    n.cspLogger.setPartnerIds(e.map(function(e) {
                        return n.parseAccount(e)
                    }).filter(function(e) {
                        return void 0 !== e
                    }))
                }
                var n = this;
                this.mConfig.trackingCallData.onAccountChange(function(e) {
                    t(void 0 === (e = e) || null == e ? [] : e instanceof Array ? e : [e])
                }),
                this.mState.app.onAccountsChange(function(e) {
                    t(e)
                }),
                d("enabledCspViolationDetection", !0) && (this.addExtraAllowedDomainsToCspLogger(),
                this.cspLogger.registerListener())
            }
            ,
            L.prototype.addExtraAllowedDomainsToCspLogger = function() {
                var e = d("allowedDomainsForCsp", []);
                this.cspLogger.addAllowedDomains(e)
            }
            ;
            var Re = L;
            function L() {
                var e, t, n, i, o, r, a, s = this, c = (void 0 !== (null == (r = null === window || void 0 === window ? void 0 : window.location) ? void 0 : r.hash) && -1 !== window.location.hash.indexOf("onetag-debug") && F.setLogLevel(f.Debug),
                this.exceptionHandler = new G,
                this.exceptions = this.exceptionHandler.exceptions,
                this.performanceMetrics = new we,
                this.performances = this.performanceMetrics.timings,
                this.performanceMetrics.startRecordingInit(),
                this.mState = {
                    app: new Pe,
                    cbs: new ke
                },
                this.mConfig = (r = this.exceptionHandler,
                a = new Q,
                t = {
                    item: !0,
                    "item.id": !0,
                    product: !0,
                    "product.id": !0
                },
                n = {
                    item: !0,
                    product: !0
                },
                u = {
                    shouldEncodeField: function(e) {
                        return t[e]
                    }
                },
                i = {
                    shouldParseField: function(e) {
                        return n[e]
                    }
                },
                o = {
                    externalIdentifiersToRead: {
                        FirstId: {
                            key: "firstid",
                            storageSource: {
                                origin: h.Cookie
                            }
                        },
                        IntimateMergerId: {
                            key: /^_im_uid\./,
                            storageSource: {
                                origin: h.LocalStorage
                            }
                        },
                        PanoramaId: {
                            key: "panoramaId",
                            storageSource: {
                                origin: h.LocalStorage
                            }
                        },
                        UtiqAdtechPass: {
                            key: "utiqPass",
                            storageSource: {
                                origin: h.LocalStorage
                            },
                            transform: function(e) {
                                var t, n, i;
                                try {
                                    return (null == (i = null == (n = null == (t = JSON.parse(e).connectId) ? void 0 : t.idGraph) ? void 0 : n[0]) ? void 0 : i.atid) || null
                                } catch (e) {
                                    return null
                                }
                            }
                        }
                    }
                },
                d("addClientSideSupportForId5") && (c = d("useStaticConsentForId5", !1),
                e = new j(c),
                r.catchAndStoreException(function() {
                    e.initialize(),
                    o.externalIdentifiersToRead.Id5 = {
                        key: "id5",
                        storageSource: {
                            origin: h.Library,
                            retrievalMethod: function() {
                                return e.getUserId()
                            }
                        }
                    }
                })),
                {
                    hooks: {},
                    shortNameMap: {
                        events: {
                            applaunched: "al",
                            viewitem: "vp",
                            viewhome: "vh",
                            viewlist: "vl",
                            viewbasket: "vb",
                            viewsearch: "vs",
                            viewpage: "vpg",
                            tracktransaction: "vc",
                            addtocart: "ac",
                            calldising: "dis",
                            setdata: "exd",
                            setemail: "ce",
                            setidentity: "id"
                        },
                        properties: {
                            event: "e",
                            account: "a",
                            first_party_identifier: "fpid",
                            currency: "c",
                            product: "p",
                            item: "p",
                            "item.id": "i",
                            "item.price": "pr",
                            "item.quantity": "q",
                            "item.availability": "pav",
                            "item.buy_box": "bb",
                            "item.sku_parent": "psp",
                            "item.store_id": "ps",
                            item_whitelist: "iw",
                            "product.id": "i",
                            "product.price": "pr",
                            "product.quantity": "q",
                            "product.availability": "pav",
                            "product.buy_box": "bb",
                            "product.sku_parent": "psp",
                            "product.store_id": "ps",
                            data: "d",
                            keywords: "kw",
                            checkin_date: "din",
                            checkout_date: "dout",
                            deduplication: "dd",
                            delivery: "dl",
                            attribution: "at",
                            "attribution.channel": "ac",
                            "attribution.value": "v",
                            user_segment: "si",
                            new_customer: "nc",
                            customer_id: "ci",
                            email: "m",
                            hash_method: "h",
                            identity: "id",
                            raw_identity: "rid",
                            transaction_value: "tv",
                            client_revenue: "cr",
                            responseType: "rt",
                            page_name: "pn",
                            page_id: "pi",
                            page_number: "pnb",
                            category: "ca",
                            filters: "f",
                            "filters.name": "fn",
                            "filters.operator": "fo",
                            "filters.value": "fv",
                            retailer_visitor_id: "rvi",
                            price: "pr",
                            availability: "av",
                            sub_event_type: "se",
                            store_id: "s",
                            item_group_id: "sp",
                            sku_parent: "sp",
                            zipcode: "z",
                            nocall: "noc",
                            block: "bl"
                        }
                    },
                    trackingCallData: a,
                    workflow: {
                        container: null,
                        disOnce: !1,
                        manualDising: !1,
                        manualFlush: !1,
                        noPartialFlush: !1,
                        partialDis: !1
                    },
                    encodingConfig: u,
                    parsingConfig: i,
                    identifierScrappingConfig: o
                }),
                this.mConfig.trackingCallData.isStepAllowed("identify")), u = (r = window.navigator.userAgent,
                a = null !== (r = r.match(Ce)),
                {
                    hasItp: null !== r && 11 <= parseFloat(r[1]),
                    isSafari: a
                });
                this.mIdentification = c ? new he(this.exceptionHandler,u,window,this.mConfig) : new fe,
                this.mSyncframe = new (c ? me : ve),
                this.mConsentManager = new Z(window),
                this.cspLogger = U.getSingleton(this.mConfig.trackingCallData.dynamic ? "dynamic.criteo.com" : "static.criteo.net", this.mConfig.trackingCallData.dynamic ? p.OneTagDynamic : p.OneTagStatic),
                this.pushLock = new se,
                this.evalQueueLock = new se,
                this.exceptionHandler.catchAndStoreException(function() {
                    s.setupCspLogger(),
                    s.mIdentification.checkAcid(),
                    s.mIdentification.checkClientSideIdentityStatus(),
                    s.mIdentification.setCop(window),
                    s.setupSyncFrameWait(),
                    S.onBodyReady(s.exceptionHandler, function() {
                        return l(s, void 0, void 0, function() {
                            var t = this;
                            return R(this, function(e) {
                                switch (e.label) {
                                case 0:
                                    return this.mConfig.hooks.onInitialized instanceof Function ? (this.mState.app.bodyReady = this.mConfig.hooks.onInitialized(),
                                    F.warn("onInitialized hook is deprecated and will soon be removed. Please do not use it and contact criteo if you think this may break your integration")) : this.mState.app.bodyReady = !0,
                                    this.mConsentManager.retrieveConsent().then(function(e) {
                                        t.tryWriteCriteoCookiesOnAdvertiserDomain(e)
                                    }),
                                    [4, this.evalQueue()];
                                case 1:
                                    return e.sent(),
                                    [2]
                                }
                            })
                        })
                    }),
                    S.onDocumentReady(s.exceptionHandler, function() {
                        return l(s, void 0, void 0, function() {
                            return R(this, function(e) {
                                switch (e.label) {
                                case 0:
                                    return this.mConfig.hooks.onDOMReady instanceof Function ? (this.mState.app.domReady = this.mConfig.hooks.onDOMReady(),
                                    F.warn("on DOM ready hook is deprecated and will soon be removed. Please do not use it and contact criteo if you think this may break your integration")) : this.mState.app.domReady = !0,
                                    [4, this.evalQueue()];
                                case 1:
                                    return e.sent(),
                                    [2]
                                }
                            })
                        })
                    });
                    var e = s.mConfig.trackingCallData.extraData;
                    try {
                        var t = S.getAnchorWithReferrer(document);
                        t && t.hostname !== document.location.hostname && ae(e, {
                            event: "setData",
                            ref: t.protocol + "//" + t.hostname
                        })
                    } catch (e) {}
                    d("visitEventEnabled", !1) && Te(s, s.mState.app, s.mConfig.trackingCallData),
                    new be(document,s,s.mConfig.trackingCallData,s.exceptionHandler).init()
                })
            }
            function Fe(e, t, n, i, o) {
                var r;
                e && 0 !== (e = e.trim()).length && (n < (e = (r = encodeURIComponent || escape)(e)).length && (t.push(o + "=" + e.length),
                e = e.substr(0, n)),
                o = r(e),
                t.push(i + "=" + o))
            }
            function _e(e) {
                var t, n;
                (!e.criteo_q || e.criteo_q instanceof Array) && (t = e.criteo_q || [],
                e.criteo_q = De({
                    exceptions: (n = new Re).exceptions,
                    performances: n.performances,
                    push: function() {
                        for (var e = [], t = 0; t < arguments.length; t++)
                            e[t] = arguments[t];
                        return n.push.apply(n, e)
                    },
                    removeLater: function(e) {
                        return n.removeLater(e)
                    },
                    pushInternal: function() {
                        for (var e = [], t = 0; t < arguments.length; t++)
                            e[t] = arguments[t];
                        return n.pushInternal.apply(n, e)
                    }
                }, n.exceptionHandler, n.mConfig, n.mState, n.performanceMetrics),
                t.adBlockDetector,
                e.criteo_q.adBlockDetector = t.adBlockDetector,
                (e = e.criteo_q).push.apply(e, t))
            }
            _e(window),
            O.wrapCriteoQ = _e,
            Object.defineProperty(O, "__esModule", {
                value: !0
            })
        }({});
    } catch {}
}
)();
